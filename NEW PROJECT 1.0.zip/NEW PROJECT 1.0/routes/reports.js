const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const {
  getDashboardKPIs,
  getSalesReport,
  getTopSellingProducts,
  getSalesCalendarData,
  getRevenueTrend
} = require('../services/reportService');
const {
  getStockForecasts,
  getReorderRecommendations
} = require('../services/forecastingService');

router.use(authenticateToken);

// GET /api/reports/dashboard
router.get('/dashboard', (req, res) => {
  try {
    const kpis = getDashboardKPIs();
    res.json(kpis);
  } catch (err) {
    console.error('Dashboard stats error:', err);
    res.status(500).json({ error: 'Failed to retrieve dashboard data' });
  }
});

// GET /api/reports/sales - Flexible sales & profit report
router.get('/sales', (req, res) => {
  try {
    const { period = 'today', start_date, end_date } = req.query;
    const report = getSalesReport({
      period,
      startDate: start_date,
      endDate: end_date
    });
    res.json(report);
  } catch (err) {
    console.error('Sales report error:', err);
    res.status(500).json({ error: 'Failed to retrieve sales report' });
  }
});

// GET /api/reports/daily
router.get('/daily', (req, res) => {
  try {
    const report = getSalesReport({ period: 'today' });
    res.json({
      kpis: {
        total_revenue: report.kpis.revenue,
        products_sold: report.kpis.units_sold,
        transactions: report.kpis.transactions,
        total_cost: report.kpis.cost,
        total_profit: report.kpis.profit,
        profit_margin: report.kpis.margin,
        average_transaction_value: report.kpis.average_transaction_value
      },
      sales: report.sales
    });
  } catch (err) {
    console.error('Daily report error:', err);
    res.status(500).json({ error: 'Failed to retrieve daily report' });
  }
});

// GET /api/reports/monthly
router.get('/monthly', (req, res) => {
  try {
    const report = getSalesReport({ period: 'month' });
    const topProducts = getTopSellingProducts({ limit: 10 });
    const trend = getRevenueTrend();

    res.json({
      kpis: {
        monthly_revenue: report.kpis.revenue,
        best_product: topProducts.length > 0 ? topProducts[0].product_name : 'N/A',
        stock_movement: report.kpis.units_sold,
        total_profit: report.kpis.profit,
        profit_margin: report.kpis.margin,
        transactions: report.kpis.transactions
      },
      best_products: topProducts,
      trend
    });
  } catch (err) {
    console.error('Monthly report error:', err);
    res.status(500).json({ error: 'Failed to retrieve monthly report' });
  }
});

// GET /api/reports/top-products
router.get('/top-products', (req, res) => {
  try {
    const { limit = 10, start_date, end_date } = req.query;
    const products = getTopSellingProducts({
      limit: parseInt(limit) || 10,
      startDate: start_date,
      endDate: end_date
    });
    res.json({ top_products: products });
  } catch (err) {
    console.error('Top products report error:', err);
    res.status(500).json({ error: 'Failed to retrieve top products' });
  }
});

// GET /api/reports/forecasts
router.get('/forecasts', (req, res) => {
  try {
    const forecasts = getStockForecasts();
    res.json({ forecasts });
  } catch (err) {
    console.error('Stock forecasts error:', err);
    res.status(500).json({ error: 'Failed to calculate stock forecasts' });
  }
});

// GET /api/reports/reorder-recommendations
router.get('/reorder-recommendations', (req, res) => {
  try {
    const recommendations = getReorderRecommendations();
    res.json({ recommendations });
  } catch (err) {
    console.error('Reorder recommendations error:', err);
    res.status(500).json({ error: 'Failed to retrieve reorder recommendations' });
  }
});

// GET /api/reports/calendar
router.get('/calendar', (req, res) => {
  try {
    const { year, month } = req.query;
    const calendar = getSalesCalendarData({
      year: year ? parseInt(year) : undefined,
      month: month ? parseInt(month) : undefined
    });
    res.json(calendar);
  } catch (err) {
    console.error('Calendar data error:', err);
    res.status(500).json({ error: 'Failed to retrieve sales calendar data' });
  }
});

// GET /api/reports/trend
router.get('/trend', (req, res) => {
  try {
    const trend = getRevenueTrend();
    res.json({ trend });
  } catch (err) {
    console.error('Trend report error:', err);
    res.status(500).json({ error: 'Failed to retrieve revenue trend' });
  }
});

module.exports = router;
