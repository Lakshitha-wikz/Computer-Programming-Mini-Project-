﻿const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { query, queryOne, run } = require('../database/db');
const { authenticateToken } = require('../middleware/auth');
const { requireAdmin } = require('../middleware/roles');

router.use(authenticateToken);
router.use(requireAdmin);

// GET /api/users
router.get('/', (req, res) => {
  try {
    const users = query(
      'SELECT id, name, email, role, status, created_at, updated_at FROM users ORDER BY id ASC'
    );
    res.json({ users });
  } catch (err) {
    console.error('Error fetching users:', err);
    res.status(500).json({ error: 'Failed to retrieve users' });
  }
});

// POST /api/users (Invite/Add user)
router.post('/', (req, res) => {
  try {
    const { name, email, role = 'sales', password = 'password123', status = 'active' } = req.body;

    if (!name || !email) {
      return res.status(400).json({ error: 'Name and email are required' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const existing = queryOne('SELECT id FROM users WHERE LOWER(email) = LOWER(?)', [cleanEmail]);
    if (existing) {
      return res.status(400).json({ error: 'User with this email already exists' });
    }

    if (!['admin', 'sales'].includes(role)) {
      return res.status(400).json({ error: 'Role must be either "admin" or "sales"' });
    }

    const passwordHash = bcrypt.hashSync(password.trim() || 'password123', 10);
    const userStatus = ['active', 'inactive', 'invited'].includes(status) ? status : 'active';

    const result = run(
      'INSERT INTO users (name, email, password_hash, role, status) VALUES (?, ?, ?, ?, ?)',
      [name.trim(), cleanEmail, passwordHash, role, userStatus]
    );

    const newUser = queryOne(
      'SELECT id, name, email, role, status, created_at FROM users WHERE id = ?',
      [result.lastInsertRowid]
    );

    res.status(201).json({ success: true, user: newUser });
  } catch (err) {
    console.error('Error creating user:', err);
    res.status(500).json({ error: 'Failed to create user: ' + err.message });
  }
});

// PUT /api/users/:id (Edit user)
router.put('/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const user = queryOne('SELECT * FROM users WHERE id = ?', [id]);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const { name = user.name, role = user.role, status = user.status, password } = req.body;

    // Prevent removing the last active admin
    if (user.role === 'admin' && (role !== 'admin' || status !== 'active')) {
      const activeAdminCount = queryOne(
        "SELECT COUNT(*) as c FROM users WHERE role = 'admin' AND status = 'active' AND id != ?",
        [id]
      ).c;
      if (activeAdminCount === 0) {
        return res.status(400).json({ error: 'Cannot deactivate or demote the last remaining active Administrator' });
      }
    }

    if (password && password.trim()) {
      const hash = bcrypt.hashSync(password.trim(), 10);
      run(
        'UPDATE users SET name = ?, role = ?, status = ?, password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [name.trim(), role, status, hash, id]
      );
    } else {
      run(
        'UPDATE users SET name = ?, role = ?, status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [name.trim(), role, status, id]
      );
    }

    const updated = queryOne('SELECT id, name, email, role, status, updated_at FROM users WHERE id = ?', [id]);
    res.json({ success: true, user: updated });
  } catch (err) {
    console.error('Error updating user:', err);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

// DELETE /api/users/:id (Deactivate user)
router.delete('/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (id === req.user.id) {
      return res.status(400).json({ error: 'You cannot delete your own account' });
    }

    const user = queryOne('SELECT * FROM users WHERE id = ?', [id]);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (user.role === 'admin') {
      const activeAdminCount = queryOne(
        "SELECT COUNT(*) as c FROM users WHERE role = 'admin' AND status = 'active' AND id != ?",
        [id]
      ).c;
      if (activeAdminCount === 0) {
        return res.status(400).json({ error: 'Cannot deactivate the last remaining active Administrator' });
      }
    }

    run("UPDATE users SET status = 'inactive', updated_at = CURRENT_TIMESTAMP WHERE id = ?", [id]);
    res.json({ success: true, message: `User ${user.name} has been deactivated` });
  } catch (err) {
    console.error('Error deleting user:', err);
    res.status(500).json({ error: 'Failed to deactivate user' });
  }
});

module.exports = router;
