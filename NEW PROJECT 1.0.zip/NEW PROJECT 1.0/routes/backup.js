const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { db, dbPath, queryOne } = require('../database/db');
const { authenticateToken } = require('../middleware/auth');
const { requireAdmin } = require('../middleware/roles');
const { logAudit } = require('../services/auditService');

router.use(authenticateToken);
router.use(requireAdmin);

// GET /api/backup/stats - Database diagnostics and table counts
router.get('/stats', (req, res) => {
  try {
    const stats = fs.statSync(dbPath);
    let walSize = 0;
    const walPath = `${dbPath}-wal`;
    if (fs.existsSync(walPath)) {
      walSize = fs.statSync(walPath).size;
    }

    const productCount = queryOne('SELECT COUNT(*) as c FROM products').c;
    const salesCount = queryOne('SELECT COUNT(*) as c FROM sales').c;
    const customerCount = queryOne('SELECT COUNT(*) as c FROM customers').c;
    const auditCount = queryOne('SELECT COUNT(*) as c FROM audit_logs').c;

    // Check backups folder
    const backupsDir = path.join(path.dirname(dbPath), 'backups');
    let snapshots = [];
    if (fs.existsSync(backupsDir)) {
      snapshots = fs.readdirSync(backupsDir)
        .filter(f => f.endsWith('.db'))
        .map(f => {
          const s = fs.statSync(path.join(backupsDir, f));
          return {
            filename: f,
            size_bytes: s.size,
            created_at: s.birthtime || s.mtime
          };
        })
        .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    }

    res.json({
      database: {
        path: dbPath,
        size_bytes: stats.size,
        size_formatted: `${(stats.size / 1024).toFixed(1)} KB`,
        wal_size_bytes: walSize,
        last_modified: stats.mtime
      },
      counts: {
        products: productCount,
        sales: salesCount,
        customers: customerCount,
        audit_logs: auditCount
      },
      snapshots
    });
  } catch (err) {
    console.error('Error fetching backup stats:', err);
    res.status(500).json({ error: 'Failed to retrieve backup stats' });
  }
});

// GET /api/backup/download - Flush WAL and download complete SQLite database file
router.get('/download', (req, res) => {
  try {
    // Flush WAL to main DB file
    db.exec('PRAGMA wal_checkpoint(TRUNCATE);');

    const dateStr = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const filename = `compstock-backup-${dateStr}.db`;

    logAudit({
      userId: req.user.id,
      userName: req.user.name,
      action: 'DATABASE_BACKUP',
      description: `Downloaded database backup snapshot (${filename})`
    });

    res.download(dbPath, filename, (err) => {
      if (err && !res.headersSent) {
        console.error('Download error:', err);
        res.status(500).json({ error: 'Failed to download database backup' });
      }
    });
  } catch (err) {
    console.error('Backup error:', err);
    res.status(500).json({ error: 'Failed to generate database backup' });
  }
});

// POST /api/backup/snapshot - Create a timestamped local snapshot
router.post('/snapshot', (req, res) => {
  try {
    db.exec('PRAGMA wal_checkpoint(TRUNCATE);');

    const backupsDir = path.join(path.dirname(dbPath), 'backups');
    if (!fs.existsSync(backupsDir)) {
      fs.mkdirSync(backupsDir, { recursive: true });
    }

    const dateStr = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const snapshotName = `compstock_snapshot_${dateStr}.db`;
    const targetPath = path.join(backupsDir, snapshotName);

    fs.copyFileSync(dbPath, targetPath);
    const stats = fs.statSync(targetPath);

    logAudit({
      userId: req.user.id,
      userName: req.user.name,
      action: 'DATABASE_SNAPSHOT',
      description: `Created database snapshot file "${snapshotName}" (${(stats.size / 1024).toFixed(1)} KB)`
    });

    res.status(201).json({
      success: true,
      message: `Snapshot created: ${snapshotName}`,
      snapshot: {
        filename: snapshotName,
        size_bytes: stats.size,
        created_at: stats.birthtime || stats.mtime
      }
    });
  } catch (err) {
    console.error('Snapshot error:', err);
    res.status(500).json({ error: 'Failed to create snapshot' });
  }
});

module.exports = router;
