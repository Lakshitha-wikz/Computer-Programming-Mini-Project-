const express = require('express');
const router = express.Router();
const PDFDocument = require('pdfkit');
const { query, queryOne } = require('../database/db');
const { authenticateToken } = require('../middleware/auth');
const { getStockForecasts } = require('../services/forecastingService');

router.use(authenticateToken);

// Helper to escape CSV cell values
function escapeCsv(val) {
  if (val === null || val === undefined) return '""';
  const str = String(val).replace(/"/g, '""');
  return `"${str}"`;
}

// Get local date YYYY-MM-DD
function getLocalDateString(d = new Date()) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Get local month YYYY-MM
function getLocalMonthString(d = new Date()) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
}

// Format 24h HH:MM:SS to 12h h:mm AM/PM
function formatTime12(timeStr) {
  if (!timeStr) return '';
  const parts = timeStr.split(':');
  if (parts.length < 2) return timeStr;
  let hour = parseInt(parts[0], 10);
  const min = parts[1];
  const ampm = hour >= 12 ? 'PM' : 'AM';
  hour = hour % 12 || 12;
  return `${hour}:${min} ${ampm}`;
}

// Format currency
function formatRs(num) {
  const val = parseFloat(num) || 0;
  return 'Rs ' + val.toLocaleString('en-LK', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

// GET /api/export/csv
router.get('/csv', (req, res) => {
  try {
    const type = req.query.type || 'daily';
    const csvRows = [];
    let filename = `compstock-export-${Date.now()}.csv`;
    const nowLocal = new Date();
    const generatedTimestamp = `${getLocalDateString(nowLocal)} ${formatTime12(nowLocal.toTimeString().split(' ')[0])}`;

    if (type === 'daily') {
      const targetDate = (req.query.date && req.query.date.trim()) ? req.query.date.trim() : getLocalDateString(nowLocal);
      filename = `compstock-daily-sales-${targetDate}.csv`;

      // 1. Fetch exact KPIs matching Reports page
      const dailyKpi = queryOne(
        `SELECT 
           COALESCE(SUM(s.total), 0) as total_revenue,
           COUNT(DISTINCT s.id) as transaction_count,
           COALESCE(SUM(si.quantity), 0) as units_sold
         FROM sales s
         LEFT JOIN sale_items si ON s.id = si.sale_id
         WHERE date(s.created_at, 'localtime') = ?`,
        [targetDate]
      );

      // 2. Fetch sales rows matching Reports page
      const sales = query(
        `SELECT s.id, s.invoice_number, time(s.created_at, 'localtime') as time_str, s.customer_name, 
           (SELECT GROUP_CONCAT(product_name || ' (' || quantity || ')', '; ') FROM sale_items WHERE sale_id = s.id) as items,
           (SELECT SUM(quantity) FROM sale_items WHERE sale_id = s.id) as items_qty,
           s.total, s.payment_status, s.payment_method
         FROM sales s
         WHERE date(s.created_at, 'localtime') = ?
         ORDER BY s.id DESC`,
        [targetDate]
      );

      // --- CSV Structure ---
      csvRows.push(['CompStock · Electronic Components & Equipment Shop'].map(escapeCsv).join(','));
      csvRows.push(['Daily Sales Report'].map(escapeCsv).join(','));
      csvRows.push([`Report Date: ${targetDate}`, `Generated At: ${generatedTimestamp}`].map(escapeCsv).join(','));
      csvRows.push([]);

      // Summary / KPIs
      csvRows.push(['--- SUMMARY METRICS ---'].map(escapeCsv).join(','));
      csvRows.push(['Metric', 'Value'].map(escapeCsv).join(','));
      csvRows.push(['Total Revenue Today', formatRs(dailyKpi.total_revenue)].map(escapeCsv).join(','));
      csvRows.push(['Products Sold', `${dailyKpi.units_sold || 0} units`].map(escapeCsv).join(','));
      csvRows.push(['Total Transactions', dailyKpi.transaction_count || 0].map(escapeCsv).join(','));
      csvRows.push([]);

      // Detailed Table
      csvRows.push(['--- TRANSACTION DETAILS ---'].map(escapeCsv).join(','));
      csvRows.push(['Sale ID', 'Time', 'Customer', 'Items Summary', 'Payment Method', 'Status', 'Total (Rs)'].map(escapeCsv).join(','));

      let sumTotal = 0;
      if (sales.length === 0) {
        csvRows.push(['No transactions recorded for this date', '', '', '', '', '', '0.00'].map(escapeCsv).join(','));
      } else {
        for (const s of sales) {
          sumTotal += s.total;
          const statusFormatted = s.payment_status ? (s.payment_status.charAt(0).toUpperCase() + s.payment_status.slice(1)) : 'Paid';
          const methodFormatted = s.payment_method ? s.payment_method.toUpperCase() : 'CASH';
          csvRows.push([
            `#${s.invoice_number}`,
            formatTime12(s.time_str),
            s.customer_name || 'Walk-in',
            s.items || '',
            methodFormatted,
            statusFormatted,
            s.total.toFixed(2)
          ].map(escapeCsv).join(','));
        }
      }

      // Totals Row
      csvRows.push([]);
      csvRows.push(['--- TOTAL CALCULATIONS ---'].map(escapeCsv).join(','));
      csvRows.push(['Total Transactions', sales.length].map(escapeCsv).join(','));
      csvRows.push(['Total Products Sold (units)', dailyKpi.units_sold || 0].map(escapeCsv).join(','));
      csvRows.push(['Total Revenue (Rs)', sumTotal.toFixed(2)].map(escapeCsv).join(','));

    } else if (type === 'monthly') {
      const targetMonth = (req.query.month && req.query.month.trim()) ? req.query.month.trim() : getLocalMonthString(nowLocal);
      filename = `compstock-monthly-report-${targetMonth}.csv`;

      // 1. Fetch Monthly KPIs matching Reports page
      const monthKpi = queryOne(
        `SELECT 
           COALESCE(SUM(s.total), 0) as monthly_revenue,
           COUNT(DISTINCT s.id) as transaction_count,
           COALESCE(SUM(si.quantity), 0) as units_sold
         FROM sales s
         LEFT JOIN sale_items si ON s.id = si.sale_id
         WHERE strftime('%Y-%m', s.created_at, 'localtime') = ?`,
        [targetMonth]
      );

      const stockMovements = queryOne(
        `SELECT COALESCE(ABS(SUM(quantity_change)), 0) as total_moved
         FROM stock_movements
         WHERE quantity_change < 0 
         AND strftime('%Y-%m', created_at, 'localtime') = ?`,
        [targetMonth]
      );

      // 2. Fetch Best Products matching Reports page
      const bestProducts = query(
        `SELECT 
           si.product_name, 
           si.sku,
           SUM(si.quantity) as units_sold,
           SUM(si.line_total) as revenue
         FROM sale_items si
         JOIN sales s ON si.sale_id = s.id
         WHERE strftime('%Y-%m', s.created_at, 'localtime') = ?
         GROUP BY si.product_id, si.product_name, si.sku
         ORDER BY revenue DESC`,
        [targetMonth]
      );

      const topProductName = bestProducts.length > 0 ? bestProducts[0].product_name : 'N/A';
      const totalUnitsMoved = stockMovements.total_moved || monthKpi.units_sold || 0;

      // --- CSV Structure ---
      csvRows.push(['CompStock · Electronic Components & Equipment Shop'].map(escapeCsv).join(','));
      csvRows.push(['Monthly Sales Report'].map(escapeCsv).join(','));
      csvRows.push([`Report Period: ${targetMonth}`, `Generated At: ${generatedTimestamp}`].map(escapeCsv).join(','));
      csvRows.push([]);

      // Summary / KPIs
      csvRows.push(['--- SUMMARY METRICS ---'].map(escapeCsv).join(','));
      csvRows.push(['Metric', 'Value'].map(escapeCsv).join(','));
      csvRows.push(['Monthly Revenue', formatRs(monthKpi.monthly_revenue)].map(escapeCsv).join(','));
      csvRows.push(['Best Selling Product', topProductName].map(escapeCsv).join(','));
      csvRows.push(['Stock Units Moved', `${totalUnitsMoved} units`].map(escapeCsv).join(','));
      csvRows.push(['Total Transactions', monthKpi.transaction_count || 0].map(escapeCsv).join(','));
      csvRows.push([]);

      // Best Products Table
      csvRows.push(['--- BEST SELLING PRODUCTS THIS MONTH ---'].map(escapeCsv).join(','));
      csvRows.push(['Rank', 'Product Name', 'SKU', 'Units Sold', 'Revenue (Rs)'].map(escapeCsv).join(','));

      let totalProductUnits = 0;
      let totalProductRevenue = 0;

      if (bestProducts.length === 0) {
        csvRows.push(['No product sales recorded for this month', '', '', '0', '0.00'].map(escapeCsv).join(','));
      } else {
        bestProducts.forEach((p, idx) => {
          totalProductUnits += p.units_sold;
          totalProductRevenue += p.revenue;
          csvRows.push([
            idx + 1,
            p.product_name,
            p.sku,
            p.units_sold,
            p.revenue.toFixed(2)
          ].map(escapeCsv).join(','));
        });
      }

      // Totals Row
      csvRows.push([]);
      csvRows.push(['--- TOTAL CALCULATIONS ---'].map(escapeCsv).join(','));
      csvRows.push(['Total Units Sold', totalProductUnits].map(escapeCsv).join(','));
      csvRows.push(['Total Product Revenue (Rs)', totalProductRevenue.toFixed(2)].map(escapeCsv).join(','));

    } else if (type === 'inventory') {
      filename = `compstock-inventory-${getLocalDateString(nowLocal)}.csv`;
      csvRows.push(['CompStock · Electronic Components & Equipment Shop'].map(escapeCsv).join(','));
      csvRows.push(['Active Inventory Catalog'].map(escapeCsv).join(','));
      csvRows.push([`Generated At: ${generatedTimestamp}`].map(escapeCsv).join(','));
      csvRows.push([]);
      csvRows.push(['Product Name', 'SKU', 'Barcode', 'Category', 'Selling Price (Rs)', 'Cost Price (Rs)', 'Current Stock', 'Low Stock Threshold', 'Status'].map(escapeCsv).join(','));

      const prods = query('SELECT * FROM products ORDER BY name ASC');
      for (const p of prods) {
        csvRows.push([
          p.name,
          p.sku,
          p.barcode || '',
          p.category,
          p.selling_price.toFixed(2),
          (p.cost_price || 0).toFixed(2),
          p.stock_quantity,
          p.low_stock_threshold,
          p.status
        ].map(escapeCsv).join(','));
      }
    } else if (type === 'customers') {
      filename = `compstock-customers-${getLocalDateString(nowLocal)}.csv`;
      csvRows.push(['CompStock · Electronic Components & Equipment Shop'].map(escapeCsv).join(','));
      csvRows.push(['Customer Directory & Spending History'].map(escapeCsv).join(','));
      csvRows.push([`Generated At: ${generatedTimestamp}`].map(escapeCsv).join(','));
      csvRows.push([]);
      csvRows.push(['Name', 'Phone', 'Email', 'Company', 'Address', 'Total Orders', 'Total Spent (Rs)', 'Last Order Date'].map(escapeCsv).join(','));

      const customers = query(`
        SELECT c.*,
          COUNT(s.id) as total_orders,
          COALESCE(SUM(s.total), 0) as total_spent,
          MAX(s.created_at) as last_order_date
        FROM customers c
        LEFT JOIN sales s ON s.customer_id = c.id
        GROUP BY c.id
        ORDER BY c.name ASC
      `);
      for (const c of customers) {
        csvRows.push([
          c.name,
          c.phone || '',
          c.email || '',
          c.company || '',
          c.address || '',
          c.total_orders,
          c.total_spent.toFixed(2),
          c.last_order_date || 'N/A'
        ].map(escapeCsv).join(','));
      }
    } else if (type === 'forecasts') {
      filename = `compstock-stock-forecast-${getLocalDateString(nowLocal)}.csv`;
      csvRows.push(['CompStock · Electronic Components & Equipment Shop'].map(escapeCsv).join(','));
      csvRows.push(['Stock Forecasting & Reorder Recommendations'].map(escapeCsv).join(','));
      csvRows.push([`Generated At: ${generatedTimestamp}`].map(escapeCsv).join(','));
      csvRows.push([]);
      csvRows.push(['Product Name', 'SKU', 'Category', 'Current Stock', 'Threshold', '30d Sold', 'Avg Daily Sales', 'Days Remaining', 'Status', 'Recommended Reorder', 'Estimated Cost (Rs)'].map(escapeCsv).join(','));

      const forecasts = getStockForecasts();
      for (const f of forecasts) {
        csvRows.push([
          f.name,
          f.sku,
          f.category,
          f.current_stock,
          f.threshold,
          f.units_sold_30d,
          f.avg_daily_sales,
          f.days_remaining,
          f.status,
          f.recommended_order,
          f.estimated_reorder_cost.toFixed(2)
        ].map(escapeCsv).join(','));
      }
    } else if (type === 'audit') {
      filename = `compstock-audit-logs-${getLocalDateString(nowLocal)}.csv`;
      csvRows.push(['CompStock · Electronic Components & Equipment Shop'].map(escapeCsv).join(','));
      csvRows.push(['System Audit Trail'].map(escapeCsv).join(','));
      csvRows.push([`Generated At: ${generatedTimestamp}`].map(escapeCsv).join(','));
      csvRows.push([]);
      csvRows.push(['Timestamp', 'User', 'Action', 'Description', 'Reference ID'].map(escapeCsv).join(','));

      const logs = query('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 500');
      for (const l of logs) {
        csvRows.push([
          l.created_at,
          l.user_name,
          l.action,
          l.description,
          l.related_id || ''
        ].map(escapeCsv).join(','));
      }
    }

    // Include UTF-8 BOM so Excel on Windows properly detects UTF-8
    const csvContent = '\uFEFF' + csvRows.join('\r\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(csvContent);
  } catch (err) {
    console.error('CSV Export Error:', err);
    res.status(500).json({ error: 'Failed to generate CSV export: ' + err.message });
  }
});

// GET /api/export/pdf - Direct Binary PDF Report Download (IA 3208 Evaluation Requirement)
router.get('/pdf', (req, res) => {
  try {
    const type = req.query.type || 'daily';
    const nowLocal = new Date();
    const generatedTimestamp = `${getLocalDateString(nowLocal)} ${formatTime12(nowLocal.toTimeString().split(' ')[0])}`;
    
    let filename = `compstock-report-${Date.now()}.pdf`;
    let reportTitle = '';
    let reportSubtitle = '';
    let kpiData = [];
    let tableHeaders = [];
    let tableRows = [];

    if (type === 'daily') {
      const targetDate = (req.query.date && req.query.date.trim()) ? req.query.date.trim() : getLocalDateString(nowLocal);
      filename = `compstock-daily-sales-${targetDate}.pdf`;
      reportTitle = 'Daily Sales Report';
      reportSubtitle = `Date: ${targetDate} | Generated: ${generatedTimestamp}`;

      const dailyKpi = queryOne(
        `SELECT 
           COALESCE(SUM(s.total), 0) as total_revenue,
           COUNT(DISTINCT s.id) as transaction_count,
           COALESCE(SUM(si.quantity), 0) as units_sold
         FROM sales s
         LEFT JOIN sale_items si ON s.id = si.sale_id
         WHERE date(s.created_at, 'localtime') = ?`,
        [targetDate]
      );

      const sales = query(
        `SELECT s.id, s.invoice_number, time(s.created_at, 'localtime') as time_str, s.customer_name, 
           (SELECT GROUP_CONCAT(product_name || ' x' || quantity, ', ') FROM sale_items WHERE sale_id = s.id) as items,
           s.total, s.payment_status, s.payment_method
         FROM sales s
         WHERE date(s.created_at, 'localtime') = ?
         ORDER BY s.id DESC`,
        [targetDate]
      );

      kpiData = [
        { label: 'Total Revenue', value: formatRs(dailyKpi.total_revenue) },
        { label: 'Products Sold', value: `${dailyKpi.units_sold || 0} units` },
        { label: 'Transactions', value: `${dailyKpi.transaction_count || 0}` }
      ];

      tableHeaders = ['Invoice #', 'Time', 'Customer', 'Items Summary', 'Status', 'Total'];
      tableRows = sales.map(s => [
        `#${s.invoice_number}`,
        formatTime12(s.time_str),
        s.customer_name || 'Walk-in Customer',
        s.items || 'Component sales',
        (s.payment_status || 'PAID').toUpperCase(),
        formatRs(s.total)
      ]);
    } else {
      const targetMonth = (req.query.month && req.query.month.trim()) ? req.query.month.trim() : getLocalMonthString(nowLocal);
      filename = `compstock-monthly-sales-${targetMonth}.pdf`;
      reportTitle = 'Monthly Sales & Inventory Report';
      reportSubtitle = `Period: ${targetMonth} | Generated: ${generatedTimestamp}`;

      const monthKpi = queryOne(
        `SELECT 
           COALESCE(SUM(s.total), 0) as monthly_revenue,
           COUNT(DISTINCT s.id) as transaction_count,
           COALESCE(SUM(si.quantity), 0) as units_sold
         FROM sales s
         LEFT JOIN sale_items si ON s.id = si.sale_id
         WHERE strftime('%Y-%m', s.created_at, 'localtime') = ?`,
        [targetMonth]
      );

      const topProducts = query(
        `SELECT 
           si.product_name, 
           si.sku,
           SUM(si.quantity) as units_sold,
           SUM(si.line_total) as revenue
         FROM sale_items si
         JOIN sales s ON si.sale_id = s.id
         WHERE strftime('%Y-%m', s.created_at, 'localtime') = ?
         GROUP BY si.product_id, si.product_name, si.sku
         ORDER BY units_sold DESC
         LIMIT 15`,
        [targetMonth]
      );

      kpiData = [
        { label: 'Monthly Revenue', value: formatRs(monthKpi.monthly_revenue) },
        { label: 'Total Units Sold', value: `${monthKpi.units_sold || 0} units` },
        { label: 'Transactions', value: `${monthKpi.transaction_count || 0}` }
      ];

      tableHeaders = ['Rank', 'Product Name', 'SKU', 'Units Sold', 'Revenue Generated'];
      tableRows = topProducts.map((p, idx) => [
        `#${idx + 1}`,
        p.product_name,
        p.sku,
        `${p.units_sold} units`,
        formatRs(p.revenue)
      ]);
    }

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

    const doc = new PDFDocument({ size: 'A4', margin: 40 });
    doc.pipe(res);

    // Header styling
    doc.rect(40, 40, doc.page.width - 80, 50).fill('#0f2038');
    doc.fillColor('#ffffff').fontSize(18).font('Helvetica-Bold').text('CompStock', 55, 52);
    doc.fontSize(10).font('Helvetica').text('Electronic Components & Equipment - Official Report', 55, 72);

    doc.fillColor('#c1652f').fontSize(14).font('Helvetica-Bold').text(reportTitle, 40, 105);
    doc.fillColor('#5c6b82').fontSize(9).font('Helvetica').text(reportSubtitle, 40, 122);

    // KPI Cards
    let kpiX = 40;
    const kpiWidth = (doc.page.width - 80 - 20) / 3;
    kpiData.forEach(k => {
      doc.rect(kpiX, 140, kpiWidth, 45).fillAndStroke('#faf9f6', '#e4e0d4');
      doc.fillColor('#5c6b82').fontSize(8).font('Helvetica-Bold').text(k.label.toUpperCase(), kpiX + 10, 148);
      doc.fillColor('#0f2038').fontSize(12).font('Helvetica-Bold').text(k.value, kpiX + 10, 162);
      kpiX += kpiWidth + 10;
    });

    // Table
    let tableY = 205;
    doc.rect(40, tableY, doc.page.width - 80, 20).fill('#0f2038');
    doc.fillColor('#ffffff').fontSize(9).font('Helvetica-Bold');
    
    const colWidths = type === 'daily' 
      ? [70, 50, 110, 175, 50, 60]
      : [40, 200, 90, 85, 100];

    let currentX = 45;
    tableHeaders.forEach((h, i) => {
      doc.text(h, currentX, tableY + 5, { width: colWidths[i] });
      currentX += colWidths[i];
    });

    tableY += 22;
    doc.font('Helvetica').fontSize(8);

    if (tableRows.length === 0) {
      doc.fillColor('#5c6b82').text('No transaction data found for this period.', 45, tableY + 10);
      tableY += 30;
    } else {
      tableRows.forEach((row, rIdx) => {
        if (tableY > doc.page.height - 70) {
          doc.addPage();
          tableY = 40;
        }
        if (rIdx % 2 === 0) {
          doc.rect(40, tableY - 2, doc.page.width - 80, 18).fill('#faf9f6');
        }
        doc.fillColor('#16233a');
        let rx = 45;
        row.forEach((cell, cIdx) => {
          doc.text(String(cell), rx, tableY + 2, { width: colWidths[cIdx], ellipsis: true });
          rx += colWidths[cIdx];
        });
        tableY += 18;
      });
    }

    // Footer
    doc.fontSize(8).fillColor('#8fa3bf').text('CompStock Automated Inventory & Sales POS System - IA 3208 Evaluation Ready', 40, doc.page.height - 35, { align: 'center', width: doc.page.width - 80 });

    doc.end();
  } catch (err) {
    console.error('Binary PDF generation error:', err);
    res.status(500).json({ error: 'Failed to generate binary PDF report: ' + err.message });
  }
});

// GET /api/export/report-pdf (Dedicated Printable/PDF Business Report)
router.get('/report-pdf', (req, res) => {
  try {
    const type = req.query.type || 'daily';
    const nowLocal = new Date();
    const generatedTimestamp = `${getLocalDateString(nowLocal)} ${formatTime12(nowLocal.toTimeString().split(' ')[0])}`;

    let reportTitle = '';
    let reportSubtitle = '';
    let kpi1Label = '', kpi1Value = '';
    let kpi2Label = '', kpi2Value = '';
    let kpi3Label = '', kpi3Value = '';
    let tableHeaders = [];
    let tableRows = [];
    let grandTotal = '';

    if (type === 'daily') {
      const targetDate = (req.query.date && req.query.date.trim()) ? req.query.date.trim() : getLocalDateString(nowLocal);
      reportTitle = 'Daily Sales Report';
      reportSubtitle = `Date: ${targetDate} · Generated: ${generatedTimestamp}`;

      const dailyKpi = queryOne(
        `SELECT 
           COALESCE(SUM(s.total), 0) as total_revenue,
           COUNT(DISTINCT s.id) as transaction_count,
           COALESCE(SUM(si.quantity), 0) as units_sold
         FROM sales s
         LEFT JOIN sale_items si ON s.id = si.sale_id
         WHERE date(s.created_at, 'localtime') = ?`,
        [targetDate]
      );

      const sales = query(
        `SELECT s.id, s.invoice_number, time(s.created_at, 'localtime') as time_str, s.customer_name, 
           (SELECT GROUP_CONCAT(product_name || ' ×' || quantity, ', ') FROM sale_items WHERE sale_id = s.id) as items,
           s.total, s.payment_status, s.payment_method
         FROM sales s
         WHERE date(s.created_at, 'localtime') = ?
         ORDER BY s.id DESC`,
        [targetDate]
      );

      kpi1Label = 'Total Revenue Today';
      kpi1Value = formatRs(dailyKpi.total_revenue);
      kpi2Label = 'Products Sold';
      kpi2Value = `${dailyKpi.units_sold || 0} units`;
      kpi3Label = 'Transactions';
      kpi3Value = `${dailyKpi.transaction_count || 0}`;

      tableHeaders = ['Sale ID', 'Time', 'Customer', 'Items Summary', 'Payment', 'Status', 'Total'];
      tableRows = sales.map(s => `
        <tr>
          <td style="font-family:monospace; font-weight:600; color:#c1652f;">#${s.invoice_number}</td>
          <td style="font-family:monospace;">${formatTime12(s.time_str)}</td>
          <td>${s.customer_name || 'Walk-in'}</td>
          <td>${s.items || 'Items'}</td>
          <td style="text-transform:uppercase;">${s.payment_method || 'CASH'}</td>
          <td><span style="padding:2px 8px; border-radius:12px; font-size:11px; font-weight:bold; background:${s.payment_status === 'paid' ? '#dcf1ea' : '#f7ecd3'}; color:${s.payment_status === 'paid' ? '#116349' : '#8a6114'};">${s.payment_status ? s.payment_status.toUpperCase() : 'PAID'}</span></td>
          <td style="text-align:right; font-family:monospace; font-weight:600;">Rs ${s.total.toLocaleString()}</td>
        </tr>
      `);

      grandTotal = formatRs(dailyKpi.total_revenue);

    } else {
      const targetMonth = (req.query.month && req.query.month.trim()) ? req.query.month.trim() : getLocalMonthString(nowLocal);
      reportTitle = 'Monthly Sales Report';
      reportSubtitle = `Period: ${targetMonth} · Generated: ${generatedTimestamp}`;

      const monthKpi = queryOne(
        `SELECT 
           COALESCE(SUM(s.total), 0) as monthly_revenue,
           COUNT(DISTINCT s.id) as transaction_count,
           COALESCE(SUM(si.quantity), 0) as units_sold
         FROM sales s
         LEFT JOIN sale_items si ON s.id = si.sale_id
         WHERE strftime('%Y-%m', s.created_at, 'localtime') = ?`,
        [targetMonth]
      );

      const stockMovements = queryOne(
        `SELECT COALESCE(ABS(SUM(quantity_change)), 0) as total_moved
         FROM stock_movements
         WHERE quantity_change < 0 
         AND strftime('%Y-%m', created_at, 'localtime') = ?`,
        [targetMonth]
      );

      const bestProducts = query(
        `SELECT 
           si.product_name, 
           si.sku,
           SUM(si.quantity) as units_sold,
           SUM(si.line_total) as revenue
         FROM sale_items si
         JOIN sales s ON si.sale_id = s.id
         WHERE strftime('%Y-%m', s.created_at, 'localtime') = ?
         GROUP BY si.product_id, si.product_name, si.sku
         ORDER BY revenue DESC`,
        [targetMonth]
      );

      const topProductName = bestProducts.length > 0 ? bestProducts[0].product_name : 'N/A';
      const totalUnitsMoved = stockMovements.total_moved || monthKpi.units_sold || 0;

      kpi1Label = 'Monthly Revenue';
      kpi1Value = formatRs(monthKpi.monthly_revenue);
      kpi2Label = 'Best Selling Product';
      kpi2Value = topProductName;
      kpi3Label = 'Stock Units Moved';
      kpi3Value = `${totalUnitsMoved} units`;

      tableHeaders = ['Rank', 'Product Name', 'SKU', 'Units Sold', 'Total Revenue'];
      tableRows = bestProducts.map((p, idx) => `
        <tr>
          <td style="font-family:monospace; font-weight:600; text-align:center;">${idx + 1}</td>
          <td><strong>${p.product_name}</strong></td>
          <td style="font-family:monospace; color:#5c6b82;">${p.sku}</td>
          <td style="text-align:right; font-family:monospace;">${p.units_sold}</td>
          <td style="text-align:right; font-family:monospace; font-weight:600;">Rs ${p.revenue.toLocaleString()}</td>
        </tr>
      `);

      grandTotal = formatRs(monthKpi.monthly_revenue);
    }

    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${reportTitle} · CompStock</title>
  <style>
    @page { size: A4 portrait; margin: 12mm; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; color: #16233a; background: #fff; margin: 0; padding: 24px; }
    .report-wrap { max-width: 800px; margin: 0 auto; }
    .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f2038; padding-bottom: 16px; margin-bottom: 20px; }
    .brand h1 { margin: 0; font-size: 24px; color: #0f2038; letter-spacing: -0.5px; }
    .brand p { margin: 4px 0 0; font-size: 12px; color: #5c6b82; }
    .title-box { text-align: right; }
    .title-box h2 { margin: 0; font-size: 20px; color: #c1652f; }
    .title-box p { margin: 4px 0 0; font-size: 11px; color: #5c6b82; font-family: monospace; }
    .kpis { display: flex; gap: 12px; margin-bottom: 24px; }
    .kpi-card { flex: 1; border: 1px solid #e4e0d4; border-radius: 8px; padding: 14px 16px; background: #faf9f6; }
    .kpi-card .lbl { font-size: 10px; font-weight: bold; text-transform: uppercase; color: #5c6b82; letter-spacing: 0.5px; }
    .kpi-card .val { font-size: 18px; font-weight: bold; margin-top: 4px; color: #0f2038; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 12px; }
    th { text-align: left; padding: 9px 12px; background: #f3f1ea; border-bottom: 1.5px solid #0f2038; font-size: 10px; text-transform: uppercase; color: #16233a; }
    td { padding: 9px 12px; border-bottom: 1px solid #e4e0d4; }
    tr:nth-child(even) { background: #faf9f6; }
    .total-box { display: flex; justify-content: flex-end; margin-top: 10px; margin-bottom: 24px; }
    .total-table { width: 260px; font-size: 13px; }
    .total-table td { padding: 6px 12px; border: none; }
    .grand-total { font-size: 16px; font-weight: bold; border-top: 2px solid #0f2038 !important; color: #0f2038; }
    .actions-bar { text-align: center; margin-bottom: 20px; }
    .btn { background: #c1652f; color: #fff; border: none; padding: 9px 20px; font-size: 13px; font-weight: bold; border-radius: 6px; cursor: pointer; }
    .btn-secondary { background: #fff; color: #16233a; border: 1px solid #e4e0d4; margin-left: 8px; }
    @media print {
      .no-print { display: none !important; }
      body { padding: 0; }
      .report-wrap { max-width: 100%; }
    }
  </style>
</head>
<body>
  <div class="actions-bar no-print">
    <button class="btn" onclick="window.print()">Print / Save as PDF</button>
    <button class="btn btn-secondary" onclick="window.close()">Close</button>
  </div>
  <div class="report-wrap">
    <div class="header">
      <div class="brand">
        <h1>CompStock</h1>
        <p>Electronic Components & Equipment Shop · Inventory & Sales</p>
      </div>
      <div class="title-box">
        <h2>${reportTitle}</h2>
        <p>${reportSubtitle}</p>
      </div>
    </div>

    <div class="kpis">
      <div class="kpi-card"><div class="lbl">${kpi1Label}</div><div class="val">${kpi1Value}</div></div>
      <div class="kpi-card"><div class="lbl">${kpi2Label}</div><div class="val">${kpi2Value}</div></div>
      <div class="kpi-card"><div class="lbl">${kpi3Label}</div><div class="val">${kpi3Value}</div></div>
    </div>

    <table>
      <thead>
        <tr>
          ${tableHeaders.map((h, i) => `<th style="${i === tableHeaders.length - 1 ? 'text-align:right;' : ''}">${h}</th>`).join('')}
        </tr>
      </thead>
      <tbody>
        ${tableRows.length > 0 ? tableRows.join('') : `<tr><td colspan="${tableHeaders.length}" style="text-align:center; padding:24px; color:#5c6b82;">No records found for this period.</td></tr>`}
      </tbody>
    </table>

    <div class="total-box">
      <table class="total-table">
        <tr class="grand-total">
          <td>Total Revenue:</td>
          <td style="text-align:right; font-family:monospace;">${grandTotal}</td>
        </tr>
      </table>
    </div>

    <div style="border-top:1px solid #e4e0d4; padding-top:12px; text-align:center; font-size:10px; color:#8fa3bf;">
      CompStock Internal Business Report · Generated on ${generatedTimestamp}
    </div>
  </div>
</body>
</html>
    `;
    res.send(html);
  } catch (err) {
    console.error('PDF Report Error:', err);
    res.status(500).send('Failed to render report PDF: ' + err.message);
  }
});

// GET /api/export/invoice/:id (Printable HTML Invoice)
router.get('/invoice/:id', (req, res) => {
  try {
    const id = req.params.id;
    const sale = queryOne(
      `SELECT s.*, 
        u.name as staff_name,
        c.phone as customer_phone,
        c.email as customer_email,
        c.address as customer_address,
        c.company as customer_company
       FROM sales s 
       LEFT JOIN users u ON s.created_by = u.id 
       LEFT JOIN customers c ON s.customer_id = c.id
       WHERE s.id = ? OR s.invoice_number = ?`,
      [id, id]
    );

    if (!sale) {
      return res.status(404).send('Invoice not found');
    }

    const items = query('SELECT * FROM sale_items WHERE sale_id = ?', [sale.id]);

    const companyName = queryOne("SELECT value FROM settings WHERE key = 'company_name'")?.value || 'CompStock';
    const companyPhone = queryOne("SELECT value FROM settings WHERE key = 'company_phone'")?.value || '+94 11 234 5678';
    const companyEmail = queryOne("SELECT value FROM settings WHERE key = 'company_email'")?.value || 'info@compstock.lk';
    const companyAddress = queryOne("SELECT value FROM settings WHERE key = 'company_address'")?.value || 'First Cross Street, Pettah, Colombo 11, Sri Lanka';

    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Invoice #${sale.invoice_number} · ${companyName}</title>
  <style>
    @page { size: A4 portrait; margin: 12mm; }
    body { font-family: 'Segoe UI', Arial, sans-serif; margin: 30px; color: #16233a; background: #fff; }
    .invoice-card { max-width: 680px; margin: 0 auto; border: 1px solid #e4e0d4; padding: 36px; border-radius: 8px; }
    .header { display: flex; justify-content: space-between; border-bottom: 2px solid #0f2038; padding-bottom: 20px; margin-bottom: 24px; }
    .brand h1 { margin: 0; font-size: 24px; color: #0f2038; }
    .brand p { margin: 4px 0 0; font-size: 12px; color: #5c6b82; line-height: 1.4; }
    .inv-details { text-align: right; }
    .inv-details h2 { margin: 0; font-size: 20px; color: #c1652f; }
    .inv-details p { margin: 4px 0 0; font-size: 13px; color: #5c6b82; }
    .meta-row { display: flex; justify-content: space-between; margin-bottom: 24px; font-size: 13px; line-height: 1.6; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 24px; font-size: 13px; }
    th { text-align: left; padding: 10px; border-bottom: 2px solid #e4e0d4; font-size: 11px; text-transform: uppercase; color: #5c6b82; }
    td { padding: 10px; border-bottom: 1px solid #e4e0d4; }
    .right { text-align: right; }
    .total-box { display: flex; justify-content: flex-end; margin-bottom: 30px; }
    .total-table { width: 280px; font-size: 13px; }
    .total-table td { padding: 6px 0; border: none; }
    .grand-total { font-size: 16px; font-weight: bold; border-top: 2px solid #0f2038 !important; padding-top: 8px !important; color: #0f2038; }
    .footer { text-align: center; font-size: 12px; color: #8fa3bf; border-top: 1px solid #e4e0d4; padding-top: 20px; }
    .print-btn { background: #c1652f; color: #fff; border: none; padding: 10px 20px; font-weight: bold; border-radius: 6px; cursor: pointer; margin-bottom: 20px; }
    .badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: bold; }
    @media print {
      .no-print { display: none; }
      body { margin: 0; }
      .invoice-card { border: none; padding: 0; }
    }
  </style>
</head>
<body>
  <div style="text-align: center;" class="no-print">
    <button class="print-btn" onclick="window.print()">Print / Save as PDF</button>
  </div>
  <div class="invoice-card">
    <div class="header">
      <div class="brand">
        <h1>${companyName}</h1>
        <p>Electronic Components & Equipment<br>${companyAddress}<br>${companyPhone} · ${companyEmail}</p>
      </div>
      <div class="inv-details">
        <h2>INVOICE</h2>
        <p><strong>#${sale.invoice_number}</strong></p>
        <p>Date: ${new Date(sale.created_at).toLocaleDateString()}</p>
      </div>
    </div>
    <div class="meta-row">
      <div>
        <strong>Billed To:</strong><br>
        <strong>${sale.customer_name}</strong><br>
        ${sale.customer_company ? `<span>${sale.customer_company}</span><br>` : ''}
        ${sale.customer_phone ? `<span>Phone: ${sale.customer_phone}</span><br>` : ''}
        ${sale.customer_email ? `<span>Email: ${sale.customer_email}</span><br>` : ''}
        Payment Status: <span class="badge" style="background:${sale.payment_status === 'paid' ? '#dcf1ea' : '#f7ecd3'}; color:${sale.payment_status === 'paid' ? '#116349' : '#8a6114'};">${sale.payment_status.toUpperCase()}</span>
      </div>
      <div style="text-align: right;">
        <strong>Processed By:</strong><br>
        ${sale.staff_name || 'Staff'}<br>
        Payment Method: <strong>${(sale.payment_method || 'CASH').toUpperCase()}</strong><br>
        ${sale.return_status && sale.return_status !== 'none' ? `<span class="badge" style="background:#fee2e2; color:#b91c1c;">RETURN: ${sale.return_status.toUpperCase()}</span>` : ''}
      </div>
    </div>
    <table>
      <thead>
        <tr>
          <th>Item / SKU</th>
          <th class="right">Unit Price</th>
          <th class="right">Qty</th>
          <th class="right">Total</th>
        </tr>
      </thead>
      <tbody>
        ${items.map(it => `
          <tr>
            <td>
              <strong>${it.product_name}</strong><br>
              <small style="color:#5c6b82">${it.sku}</small>
              ${it.returned_quantity > 0 ? `<br><small style="color:#b91c1c;">(${it.returned_quantity} returned)</small>` : ''}
            </td>
            <td class="right">Rs ${it.unit_price.toLocaleString()}</td>
            <td class="right">${it.quantity}</td>
            <td class="right">Rs ${it.line_total.toLocaleString()}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
    <div class="total-box">
      <table class="total-table">
        <tr><td>Subtotal:</td><td class="right">Rs ${sale.subtotal.toLocaleString()}</td></tr>
        ${sale.discount > 0 ? `<tr><td>Discount (${sale.discount_type === 'percentage' ? `${sale.discount_rate}%` : 'Fixed'}):</td><td class="right">- Rs ${sale.discount.toLocaleString()}</td></tr>` : ''}
        <tr class="grand-total"><td>Total Amount:</td><td class="right">Rs ${sale.total.toLocaleString()}</td></tr>
        ${sale.amount_paid > 0 ? `<tr><td>Amount Tendered:</td><td class="right">Rs ${sale.amount_paid.toLocaleString()}</td></tr>` : ''}
        ${sale.change_amount > 0 ? `<tr><td>Change Returned:</td><td class="right">Rs ${sale.change_amount.toLocaleString()}</td></tr>` : ''}
      </table>
    </div>
    <div class="footer">
      <p>Thank you for your business! Please retain this invoice for your warranty records.</p>
    </div>
  </div>
</body>
</html>
    `;
    res.send(html);
  } catch (err) {
    console.error('Invoice Render Error:', err);
    res.status(500).send('Failed to render invoice');
  }
});

module.exports = router;
