const express = require('express');
const router = express.Router();
const { query, queryOne } = require('../database/db');
const { authenticateToken } = require('../middleware/auth');
const { processSale } = require('../services/salesService');

router.use(authenticateToken);

// GET /api/sales - List sales with filters
router.get('/', (req, res) => {
  try {
    const { search, limit = 50, date, customer_id, return_status } = req.query;
    let sql = `
      SELECT s.*, 
        u.name as creator_name,
        c.phone as customer_phone,
        (SELECT GROUP_CONCAT(product_name || ' ×' || quantity, ', ') FROM sale_items WHERE sale_id = s.id) as items_summary,
        (SELECT SUM(quantity) FROM sale_items WHERE sale_id = s.id) as total_units
      FROM sales s
      LEFT JOIN users u ON s.created_by = u.id
      LEFT JOIN customers c ON s.customer_id = c.id
      WHERE 1=1
    `;
    const params = [];

    if (date) {
      sql += ' AND date(s.created_at) = date(?)';
      params.push(date);
    }

    if (customer_id) {
      sql += ' AND s.customer_id = ?';
      params.push(parseInt(customer_id));
    }

    if (return_status) {
      sql += ' AND s.return_status = ?';
      params.push(return_status);
    }

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      sql += ' AND (s.invoice_number LIKE ? OR s.customer_name LIKE ?)';
      params.push(term, term);
    }

    sql += ' ORDER BY s.id DESC LIMIT ?';
    params.push(parseInt(limit) || 50);

    const sales = query(sql, params);
    res.json({ sales });
  } catch (err) {
    console.error('Error fetching sales:', err);
    res.status(500).json({ error: 'Failed to retrieve sales' });
  }
});

// GET /api/sales/:id - Retrieve sale details by id or invoice_number
router.get('/:id', (req, res) => {
  try {
    const id = req.params.id;
    let sale = queryOne(
      `SELECT s.*, 
        u.name as creator_name,
        c.phone as customer_phone,
        c.email as customer_email,
        c.address as customer_address
       FROM sales s 
       LEFT JOIN users u ON s.created_by = u.id 
       LEFT JOIN customers c ON s.customer_id = c.id
       WHERE s.id = ? OR s.invoice_number = ?`,
      [id, id]
    );

    if (!sale) {
      return res.status(404).json({ error: 'Sale not found' });
    }

    const items = query('SELECT * FROM sale_items WHERE sale_id = ? ORDER BY id ASC', [sale.id]);
    const returns = query('SELECT * FROM returns WHERE sale_id = ? ORDER BY id DESC', [sale.id]);

    res.json({ 
      sale: { 
        ...sale, 
        items,
        returns
      } 
    });
  } catch (err) {
    console.error('Error fetching sale details:', err);
    res.status(500).json({ error: 'Failed to retrieve sale details' });
  }
});

// POST /api/sales - Checkout / Create new sale
router.post('/', (req, res) => {
  try {
    const {
      customer_id,
      customer_name,
      payment_method = 'cash',
      payment_status = 'paid',
      discount_type = 'fixed',
      discount_rate = 0,
      discount = 0,
      amount_paid = 0,
      items
    } = req.body;

    const sale = processSale({
      customerId: customer_id ? parseInt(customer_id) : null,
      customerName: customer_name,
      paymentMethod: payment_method,
      paymentStatus: payment_status,
      discountType: discount_type,
      discountRate: parseFloat(discount_rate) || 0,
      discountAmount: parseFloat(discount) || 0,
      amountPaid: parseFloat(amount_paid) || 0,
      items,
      user: req.user
    });

    res.status(201).json({
      success: true,
      message: `Sale confirmed — invoice #${sale.invoice_number} generated`,
      sale
    });
  } catch (err) {
    console.error('Sale transaction error:', err.message);
    res.status(400).json({ error: err.message || 'Failed to complete sale transaction' });
  }
});

module.exports = router;
