const express = require('express');
const router = express.Router();
const { query, queryOne } = require('../database/db');
const { authenticateToken } = require('../middleware/auth');
const { processReturn } = require('../services/salesService');

router.use(authenticateToken);

// GET /api/returns - List returns
router.get('/', (req, res) => {
  try {
    const { search, limit = 50 } = req.query;
    let sql = `
      SELECT r.*, 
        u.name as creator_name,
        s.customer_name,
        (SELECT COUNT(*) FROM return_items WHERE return_id = r.id) as item_count,
        (SELECT SUM(quantity) FROM return_items WHERE return_id = r.id) as total_returned_qty
      FROM returns r
      LEFT JOIN users u ON r.created_by = u.id
      LEFT JOIN sales s ON r.sale_id = s.id
      WHERE 1=1
    `;
    const params = [];

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      sql += ' AND (r.return_number LIKE ? OR r.invoice_number LIKE ? OR s.customer_name LIKE ?)';
      params.push(term, term, term);
    }

    sql += ' ORDER BY r.id DESC LIMIT ?';
    params.push(parseInt(limit) || 50);

    const returns = query(sql, params);
    res.json({ returns });
  } catch (err) {
    console.error('Error fetching returns:', err);
    res.status(500).json({ error: 'Failed to retrieve returns list' });
  }
});

// GET /api/returns/:id - Return details with items
router.get('/:id', (req, res) => {
  try {
    const id = req.params.id;
    const ret = queryOne(
      `SELECT r.*, u.name as creator_name, s.customer_name 
       FROM returns r 
       LEFT JOIN users u ON r.created_by = u.id 
       LEFT JOIN sales s ON r.sale_id = s.id 
       WHERE r.id = ? OR r.return_number = ?`,
      [id, id]
    );

    if (!ret) {
      return res.status(404).json({ error: 'Return record not found' });
    }

    const items = query('SELECT * FROM return_items WHERE return_id = ? ORDER BY id ASC', [ret.id]);
    res.json({ return: { ...ret, items } });
  } catch (err) {
    console.error('Error fetching return details:', err);
    res.status(500).json({ error: 'Failed to retrieve return details' });
  }
});

// POST /api/returns - Process customer return
router.post('/', (req, res) => {
  try {
    const { invoice_number, items, reason } = req.body;

    if (!invoice_number) {
      return res.status(400).json({ error: 'Original invoice number is required' });
    }

    const returnResult = processReturn({
      invoiceNumber: invoice_number,
      items,
      reason: reason || 'Customer Return',
      user: req.user
    });

    res.status(201).json({
      success: true,
      message: `Return #${returnResult.return_number} processed successfully`,
      return: returnResult
    });
  } catch (err) {
    console.error('Error processing return:', err.message);
    res.status(400).json({ error: err.message || 'Failed to process return' });
  }
});

module.exports = router;
