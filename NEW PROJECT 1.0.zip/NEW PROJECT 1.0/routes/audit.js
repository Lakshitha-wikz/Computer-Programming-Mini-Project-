const express = require('express');
const router = express.Router();
const { query, queryOne } = require('../database/db');
const { authenticateToken } = require('../middleware/auth');
const { requireAdmin } = require('../middleware/roles');

router.use(authenticateToken);
router.use(requireAdmin);

// GET /api/audit - List audit logs with pagination and filters
router.get('/', (req, res) => {
  try {
    const { action, search, user_id, limit = 50, offset = 0 } = req.query;
    let sql = 'SELECT * FROM audit_logs WHERE 1=1';
    const params = [];

    if (action && action.trim()) {
      sql += ' AND action = ?';
      params.push(action.trim());
    }

    if (user_id) {
      sql += ' AND user_id = ?';
      params.push(parseInt(user_id));
    }

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      sql += ' AND (description LIKE ? OR user_name LIKE ? OR action LIKE ? OR related_id LIKE ?)';
      params.push(term, term, term, term);
    }

    // Count query
    const countSql = sql.replace('SELECT *', 'SELECT COUNT(*) as total');
    const totalRow = queryOne(countSql, params);
    const total = totalRow ? totalRow.total : 0;

    sql += ' ORDER BY id DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit) || 50, parseInt(offset) || 0);

    const logs = query(sql, params);

    // Get distinct actions for filtering
    const actions = query('SELECT DISTINCT action FROM audit_logs ORDER BY action ASC').map(r => r.action);

    res.json({
      logs,
      total,
      actions,
      limit: parseInt(limit) || 50,
      offset: parseInt(offset) || 0
    });
  } catch (err) {
    console.error('Error fetching audit logs:', err);
    res.status(500).json({ error: 'Failed to retrieve audit logs' });
  }
});

module.exports = router;
