const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const { getNotifications } = require('../services/notificationService');

router.use(authenticateToken);

// GET /api/notifications
router.get('/', (req, res) => {
  try {
    const notifications = getNotifications();
    const urgentCount = notifications.filter(n => n.type === 'danger' || n.type === 'warning').length;
    res.json({
      notifications,
      unread_count: urgentCount
    });
  } catch (err) {
    console.error('Error fetching notifications:', err);
    res.status(500).json({ error: 'Failed to retrieve notifications' });
  }
});

module.exports = router;
