const express = require('express');
const router = express.Router();
const { query, queryOne, run } = require('../database/db');
const { authenticateToken } = require('../middleware/auth');
const { logAudit } = require('../services/auditService');

router.use(authenticateToken);

// GET /api/customers - List customers with stats
router.get('/', (req, res) => {
  try {
    const { search, status, limit = 100 } = req.query;
    let sql = `
      SELECT c.*,
        COUNT(s.id) as total_orders,
        COALESCE(SUM(s.total), 0) as total_spent,
        MAX(s.created_at) as last_order_date
      FROM customers c
      LEFT JOIN sales s ON s.customer_id = c.id
      WHERE 1=1
    `;
    const params = [];

    if (status && status !== 'all') {
      sql += ' AND c.status = ?';
      params.push(status);
    }

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      sql += ' AND (c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ? OR c.address LIKE ? OR c.company LIKE ?)';
      params.push(term, term, term, term, term);
    }

    sql += ' GROUP BY c.id ORDER BY c.name ASC LIMIT ?';
    params.push(parseInt(limit) || 100);

    const customers = query(sql, params);
    res.json({ customers });
  } catch (err) {
    console.error('Error fetching customers:', err);
    res.status(500).json({ error: 'Failed to retrieve customers' });
  }
});

// GET /api/customers/:id - Customer details
router.get('/:id', (req, res) => {
  try {
    const customer = queryOne(
      `SELECT c.*,
        COUNT(s.id) as total_orders,
        COALESCE(SUM(s.total), 0) as total_spent,
        MAX(s.created_at) as last_order_date
       FROM customers c
       LEFT JOIN sales s ON s.customer_id = c.id
       WHERE c.id = ?
       GROUP BY c.id`,
      [req.params.id]
    );

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    res.json({ customer });
  } catch (err) {
    console.error('Error fetching customer details:', err);
    res.status(500).json({ error: 'Failed to retrieve customer details' });
  }
});

// GET /api/customers/:id/purchases - Customer order history
router.get('/:id/purchases', (req, res) => {
  try {
    const customerId = req.params.id;
    const customer = queryOne('SELECT * FROM customers WHERE id = ?', [customerId]);
    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    const sales = query(
      `SELECT s.*, 
        u.name as creator_name,
        (SELECT GROUP_CONCAT(product_name || ' ×' || quantity, ', ') FROM sale_items WHERE sale_id = s.id) as items_summary,
        (SELECT SUM(quantity) FROM sale_items WHERE sale_id = s.id) as total_units
       FROM sales s
       LEFT JOIN users u ON s.created_by = u.id
       WHERE s.customer_id = ?
       ORDER BY s.id DESC`,
      [customerId]
    );

    const itemsPurchased = query(
      `SELECT si.product_id, si.product_name, si.sku, 
        SUM(si.quantity) as total_quantity, 
        SUM(si.line_total) as total_amount,
        MAX(s.created_at) as last_purchased_at
       FROM sale_items si
       JOIN sales s ON si.sale_id = s.id
       WHERE s.customer_id = ?
       GROUP BY si.product_id, si.product_name, si.sku
       ORDER BY total_quantity DESC`,
      [customerId]
    );

    res.json({
      customer,
      sales,
      items_purchased: itemsPurchased
    });
  } catch (err) {
    console.error('Error fetching customer purchase history:', err);
    res.status(500).json({ error: 'Failed to retrieve purchase history' });
  }
});

// POST /api/customers - Create new customer
router.post('/', (req, res) => {
  try {
    const { name, phone, email, address, company, status = 'active' } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Customer name is required' });
    }

    // Check duplicate phone if provided
    if (phone && phone.trim()) {
      const existing = queryOne('SELECT id FROM customers WHERE phone = ?', [phone.trim()]);
      if (existing) {
        return res.status(400).json({ error: 'A customer with this phone number already exists' });
      }
    }

    const result = run(
      `INSERT INTO customers (name, phone, email, address, company, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
      [
        name.trim(),
        phone ? phone.trim() : null,
        email ? email.trim() : null,
        address ? address.trim() : null,
        company ? company.trim() : null,
        status === 'inactive' ? 'inactive' : 'active'
      ]
    );

    const newCustomer = queryOne('SELECT * FROM customers WHERE id = ?', [result.lastInsertRowid]);

    logAudit({
      userId: req.user.id,
      userName: req.user.name,
      action: 'CREATE_CUSTOMER',
      description: `Created customer "${newCustomer.name}" (${newCustomer.phone || 'No phone'})`,
      relatedId: newCustomer.id
    });

    res.status(201).json({
      success: true,
      message: 'Customer registered successfully',
      customer: newCustomer
    });
  } catch (err) {
    console.error('Error creating customer:', err);
    res.status(500).json({ error: 'Failed to create customer' });
  }
});

// PUT /api/customers/:id - Update customer
router.put('/:id', (req, res) => {
  try {
    const id = req.params.id;
    const existing = queryOne('SELECT * FROM customers WHERE id = ?', [id]);
    if (!existing) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    const { name, phone, email, address, company, status } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Customer name is required' });
    }

    if (phone && phone.trim()) {
      const duplicate = queryOne('SELECT id FROM customers WHERE phone = ? AND id != ?', [phone.trim(), id]);
      if (duplicate) {
        return res.status(400).json({ error: 'Another customer already has this phone number' });
      }
    }

    const newStatus = status !== undefined ? (status === 'inactive' ? 'inactive' : 'active') : existing.status;

    run(
      `UPDATE customers 
       SET name = ?, phone = ?, email = ?, address = ?, company = ?, status = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [
        name.trim(),
        phone ? phone.trim() : null,
        email ? email.trim() : null,
        address ? address.trim() : null,
        company ? company.trim() : null,
        newStatus,
        id
      ]
    );

    const updated = queryOne('SELECT * FROM customers WHERE id = ?', [id]);

    logAudit({
      userId: req.user.id,
      userName: req.user.name,
      action: 'UPDATE_CUSTOMER',
      description: `Updated customer details for "${updated.name}" (ID #${id}, Status: ${newStatus})`,
      relatedId: id
    });

    res.json({
      success: true,
      message: 'Customer updated successfully',
      customer: updated
    });
  } catch (err) {
    console.error('Error updating customer:', err);
    res.status(500).json({ error: 'Failed to update customer' });
  }
});

// DELETE /api/customers/:id - Deactivate or Delete customer
router.delete('/:id', (req, res) => {
  try {
    const id = req.params.id;
    const customer = queryOne('SELECT * FROM customers WHERE id = ?', [id]);
    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    const salesCount = queryOne('SELECT COUNT(*) as count FROM sales WHERE customer_id = ?', [id]);
    if (salesCount && salesCount.count > 0) {
      // Soft-deactivate if associated sales exist to protect historical integrity
      run("UPDATE customers SET status = 'inactive', updated_at = CURRENT_TIMESTAMP WHERE id = ?", [id]);

      logAudit({
        userId: req.user.id,
        userName: req.user.name,
        action: 'DEACTIVATE_CUSTOMER',
        description: `Deactivated customer "${customer.name}" (ID #${id}) with ${salesCount.count} existing orders`,
        relatedId: id
      });

      return res.json({ 
        success: true, 
        message: `Customer "${customer.name}" has ${salesCount.count} purchase invoice(s) and was deactivated to preserve sales history.` 
      });
    }

    run('DELETE FROM customers WHERE id = ?', [id]);

    logAudit({
      userId: req.user.id,
      userName: req.user.name,
      action: 'DELETE_CUSTOMER',
      description: `Deleted customer "${customer.name}" (ID #${id})`,
      relatedId: id
    });

    res.json({ success: true, message: 'Customer deleted successfully' });
  } catch (err) {
    console.error('Error deleting customer:', err);
    res.status(500).json({ error: 'Failed to delete customer' });
  }
});

module.exports = router;
