const express = require('express');
const router = express.Router();
const { query, queryOne, run, transaction } = require('../database/db');
const { authenticateToken } = require('../middleware/auth');
const { requireAdmin } = require('../middleware/roles');
const { getValuation, searchProducts, adjustStock } = require('../services/inventoryService');
const { logAudit } = require('../services/auditService');

// Apply authentication to all product routes
router.use(authenticateToken);

// GET /api/products/valuation
router.get('/valuation', (req, res) => {
  try {
    const valuation = getValuation();
    res.json({ success: true, valuation });
  } catch (err) {
    console.error('Valuation error:', err);
    res.status(500).json({ error: 'Failed to compute inventory valuation' });
  }
});

// GET /api/products/global-search?q=...
router.get('/global-search', (req, res) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) {
      return res.json({ products: [], invoices: [], customers: [] });
    }

    const term = `%${q}%`;

    // 1. Match products
    const prods = query(
      `SELECT id, name, sku, barcode, category, selling_price, stock_quantity, status 
       FROM products 
       WHERE name LIKE ? OR sku LIKE ? OR barcode LIKE ? 
       ORDER BY id DESC 
       LIMIT 25`,
      [term, term, term]
    );

    // 2. Match invoices
    const invs = query(
      `SELECT id, invoice_number, customer_name, total, payment_status, created_at 
       FROM sales 
       WHERE invoice_number LIKE ? OR customer_name LIKE ? 
       ORDER BY id DESC 
       LIMIT 15`,
      [term, term]
    );

    // 3. Match customers
    const custs = query(
      `SELECT id, name, phone, email, status 
       FROM customers 
       WHERE name LIKE ? OR phone LIKE ? OR email LIKE ? 
       LIMIT 6`,
      [term, term, term]
    );

    res.json({
      query: q,
      products: prods,
      invoices: invs,
      sales: invs,
      customers: custs
    });
  } catch (err) {
    console.error('Global search error:', err);
    res.status(500).json({ error: 'Global search failed' });
  }
});

// GET /api/products/barcode/:code (Fast lookup by barcode or SKU for POS keyboard/scanner)
router.get('/barcode/:code', (req, res) => {
  try {
    const code = req.params.code.trim();
    let product = queryOne(
      'SELECT * FROM products WHERE (barcode = ? OR UPPER(sku) = UPPER(?)) AND status = ?',
      [code, code, 'active']
    );

    if (!product) {
      // Partial SKU fallback
      product = queryOne(
        'SELECT * FROM products WHERE (sku LIKE ? OR name LIKE ?) AND status = ? LIMIT 1',
        [`%${code}%`, `%${code}%`, 'active']
      );
    }

    if (!product) {
      return res.status(404).json({ error: `Product not found for code "${code}"` });
    }

    res.json({ success: true, product });
  } catch (err) {
    console.error('Barcode lookup error:', err);
    res.status(500).json({ error: 'Failed to look up barcode' });
  }
});

// GET /api/products/categories (All active and distinct categories)
router.get('/categories', (req, res) => {
  try {
    const cats = query(
      `SELECT DISTINCT name FROM (
         SELECT name FROM categories 
         UNION 
         SELECT category AS name FROM products WHERE category IS NOT NULL AND TRIM(category) != ''
       ) ORDER BY name COLLATE NOCASE ASC`
    );
    res.json({ categories: cats.map(c => c.name) });
  } catch (err) {
    console.error('Error fetching categories:', err);
    res.status(500).json({ error: 'Failed to retrieve categories' });
  }
});

// GET /api/products (Advanced Parametric Search & Filter)
router.get('/', (req, res) => {
  try {
    const { category, search, status, stockLevel, minPrice, maxPrice, limit, offset } = req.query;
    const products = searchProducts({ category, search, status, stockLevel, minPrice, maxPrice, limit, offset });
    res.json({ products });
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ error: 'Failed to retrieve products' });
  }
});

// GET /api/products/:id
router.get('/:id', (req, res) => {
  try {
    const product = queryOne('SELECT * FROM products WHERE id = ?', [req.params.id]);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    let stockStatus = 'Normal';
    if (product.stock_quantity === 0) stockStatus = 'Out of Stock';
    else if (product.stock_quantity <= product.low_stock_threshold) stockStatus = 'Low Stock';

    res.json({
      product: {
        ...product,
        stock_status: stockStatus
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve product' });
  }
});

// GET /api/products/:id/history (Sales History and Stock Movements for Product Details View)
router.get('/:id/history', (req, res) => {
  try {
    const id = req.params.id;
    const product = queryOne('SELECT * FROM products WHERE id = ?', [id]);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    // Stock movements
    const movements = query(
      `SELECT sm.*, u.name as user_name 
       FROM stock_movements sm 
       LEFT JOIN users u ON sm.user_id = u.id 
       WHERE sm.product_id = ? 
       ORDER BY sm.id DESC LIMIT 20`,
      [id]
    );

    // Recent sales lines
    const salesLines = query(
      `SELECT si.*, s.invoice_number, s.customer_name, s.created_at, s.payment_status 
       FROM sale_items si 
       JOIN sales s ON si.sale_id = s.id 
       WHERE si.product_id = ? 
       ORDER BY s.id DESC LIMIT 15`,
      [id]
    );

    // Summary numbers
    const stats = queryOne(
      `SELECT 
         COALESCE(SUM(quantity), 0) as total_units_sold,
         COALESCE(SUM(line_total), 0) as total_revenue_generated,
         COALESCE(SUM((unit_price - unit_cost) * quantity), 0) as total_profit_generated
       FROM sale_items 
       WHERE product_id = ?`,
      [id]
    );

    res.json({
      product,
      stats: {
        totalUnitsSold: stats ? stats.total_units_sold : 0,
        totalRevenue: stats ? stats.total_revenue_generated : 0,
        totalProfit: stats ? stats.total_profit_generated : 0,
        unitProfit: product.selling_price - (product.cost_price || 0),
        profitMargin: product.selling_price > 0 
          ? Math.round(((product.selling_price - (product.cost_price || 0)) / product.selling_price) * 100) 
          : 0
      },
      movements,
      history: movements,
      sales: salesLines
    });
  } catch (err) {
    console.error('Error fetching product history:', err);
    res.status(500).json({ error: 'Failed to retrieve product history' });
  }
});

const categoryPrefixes = {
  'Microcontrollers': 'MCU',
  'Development Boards': 'DEV',
  'Sensors': 'SEN',
  'Wireless & RF': 'WRL',
  'Motors & Drivers': 'MTR',
  'Power & Batteries': 'PWR',
  'Displays': 'DSP',
  'Semiconductors': 'SMC',
  'Passive Components': 'PAS',
  'Soldering & Tools': 'TLS',
  'Modules': 'MOD',
  'Resistors': 'RES',
  'Capacitors': 'CAP',
  'Diodes': 'DIO',
  'LEDs': 'LED',
  'Transistors': 'TRN',
  'ICs': 'IC',
  'Voltage Regulators': 'VREG',
  'Relays': 'RLY'
};

const allowedIcons = ['cpu', 'chip', 'res', 'sen', 'disp'];
function inferIcon(category) {
  if (!category) return 'chip';
  const c = String(category).toLowerCase();
  if (c.includes('microcontroller') || c.includes('cpu') || c.includes('dev') || c.includes('ic') || c.includes('board')) return 'cpu';
  if (c.includes('sensor')) return 'sen';
  if (c.includes('display') || c.includes('led') || c.includes('screen')) return 'disp';
  if (c.includes('resistor') || c.includes('capacitor') || c.includes('diode') || c.includes('passive')) return 'res';
  return 'chip';
}

// POST /api/products (Admin only)
router.post('/', requireAdmin, (req, res) => {
  try {
    const {
      name,
      sku,
      barcode,
      category = 'Microcontrollers',
      supplier = '',
      description = '',
      selling_price,
      cost_price = 0,
      stock_quantity = 0,
      low_stock_threshold = 8,
      icon
    } = req.body;

    if (!name || !name.trim() || selling_price === undefined) {
      return res.status(400).json({ error: 'Product name and selling price are required' });
    }

    let cleanSku = sku ? sku.trim().toUpperCase() : '';
    if (!cleanSku) {
      let pfx = categoryPrefixes[category];
      if (!pfx) {
        const letters = (category || '').replace(/[^a-zA-Z]/g, '').toUpperCase();
        pfx = letters.length >= 3 ? letters.slice(0, 3) : 'PRD';
      }
      let attempts = 0;
      do {
        attempts++;
        cleanSku = `${pfx}-${Math.floor(1000 + Math.random() * 9000)}`;
      } while (queryOne('SELECT id FROM products WHERE sku = ?', [cleanSku]) && attempts < 50);
    } else {
      const existing = queryOne('SELECT id FROM products WHERE sku = ?', [cleanSku]);
      if (existing) {
        return res.status(400).json({ error: `Product with SKU "${cleanSku}" already exists` });
      }
    }

    let cleanBarcode = barcode && barcode.trim() ? barcode.trim() : null;
    if (!cleanBarcode) {
      let attempts = 0;
      do {
        attempts++;
        cleanBarcode = `4791${Math.floor(10000000 + Math.random() * 90000000)}`;
      } while (queryOne('SELECT id FROM products WHERE barcode = ?', [cleanBarcode]) && attempts < 50);
    } else {
      const existingBc = queryOne('SELECT id FROM products WHERE barcode = ?', [cleanBarcode]);
      if (existingBc) {
        return res.status(400).json({ error: `Product with Barcode "${cleanBarcode}" already exists` });
      }
    }

    const price = parseFloat(selling_price);
    const cost = parseFloat(cost_price) || 0;
    const stock = parseInt(stock_quantity) || 0;
    const threshold = parseInt(low_stock_threshold) || 8;
    const cleanSupplier = (supplier || '').trim();
    const cleanCategory = (category || 'General').trim();
    const validIcon = (icon && allowedIcons.includes(icon)) ? icon : inferIcon(cleanCategory);

    if (isNaN(price) || price < 0) {
      return res.status(400).json({ error: 'Selling price must be a valid non-negative number' });
    }
    if (stock < 0) {
      return res.status(400).json({ error: 'Stock quantity cannot be negative' });
    }

    let newProduct = null;
    transaction(() => {
      // Ensure category is registered in categories table
      if (cleanCategory) {
        run('INSERT OR IGNORE INTO categories (name) VALUES (?)', [cleanCategory]);
      }

      const insertRes = run(
        `INSERT INTO products 
         (name, sku, barcode, category, description, supplier, selling_price, cost_price, stock_quantity, low_stock_threshold, icon, status) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [name.trim(), cleanSku, cleanBarcode, cleanCategory, description.trim(), cleanSupplier, price, cost, stock, threshold, validIcon, 'active']
      );
      const productId = insertRes.lastInsertRowid;

      if (stock > 0) {
        run(
          `INSERT INTO stock_movements 
           (product_id, previous_quantity, quantity_change, new_quantity, reason, reference_id, user_id) 
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [productId, 0, stock, stock, 'initial_stock', 'ADD_PRODUCT', req.user.id]
        );
      }

      logAudit({
        userId: req.user.id,
        userName: req.user.name,
        action: 'CREATE_PRODUCT',
        description: `Created new product "${name.trim()}" (SKU: ${cleanSku}, Price: Rs ${price})`,
        relatedId: cleanSku
      });

      newProduct = queryOne('SELECT * FROM products WHERE id = ?', [productId]);
    });

    res.status(201).json({ success: true, product: newProduct });
  } catch (err) {
    console.error('Error creating product:', err);
    res.status(500).json({ error: 'Failed to create product: ' + err.message });
  }
});

// PUT /api/products/:id (Admin only)
router.put('/:id', requireAdmin, (req, res) => {
  try {
    const id = req.params.id;
    const existing = queryOne('SELECT * FROM products WHERE id = ?', [id]);
    if (!existing) {
      return res.status(404).json({ error: 'Product not found' });
    }

    const {
      name = existing.name,
      sku = existing.sku,
      barcode = existing.barcode,
      category = existing.category,
      supplier = existing.supplier,
      description = existing.description,
      selling_price = existing.selling_price,
      cost_price = existing.cost_price,
      low_stock_threshold = existing.low_stock_threshold,
      icon,
      status = existing.status
    } = req.body;

    const cleanSku = sku.trim().toUpperCase();
    if (cleanSku !== existing.sku) {
      const dup = queryOne('SELECT id FROM products WHERE sku = ? AND id != ?', [cleanSku, id]);
      if (dup) {
        return res.status(400).json({ error: `Product with SKU "${cleanSku}" already exists` });
      }
    }

    const cleanBarcode = barcode && barcode.trim() ? barcode.trim() : null;
    if (cleanBarcode && cleanBarcode !== existing.barcode) {
      const dupBc = queryOne('SELECT id FROM products WHERE barcode = ? AND id != ?', [cleanBarcode, id]);
      if (dupBc) {
        return res.status(400).json({ error: `Product with Barcode "${cleanBarcode}" already exists` });
      }
    }

    const price = parseFloat(selling_price);
    const cost = parseFloat(cost_price);
    const threshold = parseInt(low_stock_threshold);
    const cleanSupplier = (supplier !== undefined ? supplier : (existing.supplier || '')).trim();
    const cleanCategory = (category || existing.category || 'General').trim();
    const validIcon = (icon && allowedIcons.includes(icon)) ? icon : (existing.icon || inferIcon(cleanCategory));

    if (isNaN(price) || price < 0) {
      return res.status(400).json({ error: 'Invalid price' });
    }

    // Ensure category is registered in categories table
    if (cleanCategory) {
      run('INSERT OR IGNORE INTO categories (name) VALUES (?)', [cleanCategory]);
    }

    run(
      `UPDATE products 
       SET name = ?, sku = ?, barcode = ?, category = ?, supplier = ?, description = ?, selling_price = ?, cost_price = ?, low_stock_threshold = ?, icon = ?, status = ?, updated_at = CURRENT_TIMESTAMP 
       WHERE id = ?`,
      [name.trim(), cleanSku, cleanBarcode, cleanCategory, cleanSupplier, (description || '').trim(), price, cost, threshold, validIcon, status, id]
    );

    logAudit({
      userId: req.user.id,
      userName: req.user.name,
      action: 'UPDATE_PRODUCT',
      description: `Updated product "${existing.name}" (${cleanSku}): Price Rs ${existing.selling_price} → Rs ${price}, Status: ${status}`,
      relatedId: cleanSku
    });

    const updated = queryOne('SELECT * FROM products WHERE id = ?', [id]);
    res.json({ success: true, product: updated });
  } catch (err) {
    console.error('Error updating product:', err);
    res.status(500).json({ error: 'Failed to update product: ' + err.message });
  }
});

// DELETE /api/products/:id (Admin only - soft delete)
router.delete('/:id', requireAdmin, (req, res) => {
  try {
    const id = req.params.id;
    const existing = queryOne('SELECT * FROM products WHERE id = ?', [id]);
    if (!existing) {
      return res.status(404).json({ error: 'Product not found' });
    }

    // Soft delete product by setting status to inactive
    run("UPDATE products SET status = 'inactive', updated_at = CURRENT_TIMESTAMP WHERE id = ?", [id]);

    logAudit({
      userId: req.user.id,
      userName: req.user.name,
      action: 'DEACTIVATE_PRODUCT',
      description: `Deactivated product "${existing.name}" (${existing.sku})`,
      relatedId: existing.sku
    });

    res.json({ success: true, message: `Product ${existing.sku} deactivated successfully` });
  } catch (err) {
    console.error('Error deleting product:', err);
    res.status(500).json({ error: 'Failed to deactivate product' });
  }
});

// POST /api/products/:id/stock-adjustment (Admin only)
router.post('/:id/stock-adjustment', requireAdmin, (req, res) => {
  try {
    const id = req.params.id;
    const { delta, new_stock, reason = 'manual_adjustment' } = req.body;

    const updatedProduct = adjustStock({
      productId: id,
      delta,
      newStock: new_stock,
      reason,
      user: req.user
    });

    res.json({ success: true, product: updatedProduct });
  } catch (err) {
    console.error('Error adjusting stock:', err);
    res.status(400).json({ error: err.message || 'Failed to adjust stock' });
  }
});

module.exports = router;
