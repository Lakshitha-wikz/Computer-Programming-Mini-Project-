const express = require('express');
const router = express.Router();
const { query, queryOne, run } = require('../database/db');
const { authenticateToken } = require('../middleware/auth');
const { requireAdmin } = require('../middleware/roles');
const { logAudit } = require('../services/auditService');

router.use(authenticateToken);

// GET /api/settings - Read system settings
router.get('/', (req, res) => {
  try {
    const rows = query('SELECT key, value, updated_at FROM settings');
    const settings = {};
    for (const r of rows) {
      settings[r.key] = r.value;
    }
    res.json({ settings });
  } catch (err) {
    console.error('Error fetching settings:', err);
    res.status(500).json({ error: 'Failed to retrieve settings' });
  }
});

// PUT /api/settings - Update system settings (Admin only)
router.put('/', requireAdmin, (req, res) => {
  try {
    const allowedKeys = [
      'company_name',
      'company_phone',
      'company_email',
      'company_address',
      'currency',
      'low_stock_default',
      'invoice_prefix'
    ];

    const updates = req.body;
    let updateCount = 0;

    for (const key of allowedKeys) {
      if (updates[key] !== undefined) {
        const val = String(updates[key]);
        const exists = queryOne('SELECT key FROM settings WHERE key = ?', [key]);
        if (exists) {
          run('UPDATE settings SET value = ?, updated_at = CURRENT_TIMESTAMP WHERE key = ?', [val, key]);
        } else {
          run('INSERT INTO settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)', [key, val]);
        }
        updateCount++;
      }
    }

    logAudit({
      userId: req.user.id,
      userName: req.user.name,
      action: 'UPDATE_SETTINGS',
      description: `Updated ${updateCount} system configuration setting(s)`
    });

    const rows = query('SELECT key, value FROM settings');
    const settings = {};
    for (const r of rows) {
      settings[r.key] = r.value;
    }

    res.json({
      success: true,
      message: 'System settings updated successfully',
      settings
    });
  } catch (err) {
    console.error('Error updating settings:', err);
    res.status(500).json({ error: 'Failed to update settings' });
  }
});

module.exports = router;
