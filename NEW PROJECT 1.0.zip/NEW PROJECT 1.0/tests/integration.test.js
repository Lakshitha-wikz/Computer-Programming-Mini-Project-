const http = require('http');
const db = require('../database/db');

async function request(options, body = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        let json = null;
        try { json = JSON.parse(data); } catch (e) { json = data; }
        resolve({
          status: res.statusCode,
          headers: res.headers,
          data: json
        });
      });
    });
    req.on('error', reject);
    if (body) {
      req.write(typeof body === 'object' ? JSON.stringify(body) : body);
    }
    req.end();
  });
}

async function ensureServerRunning() {
  try {
    await request({ hostname: 'localhost', port: 3000, path: '/api/auth/me', method: 'GET' });
  } catch (err) {
    console.log('Spawning application server for integration testing...');
    require('../server.js');
    await new Promise(r => setTimeout(r, 1200));
  }
}

async function runTests() {
  await ensureServerRunning();

  // Ensure default test accounts are active
  try {
    db.run("UPDATE users SET status = 'active' WHERE email IN ('admin@compstock.lk', 'staff@compstock.lk')");
  } catch (e) {}

  console.log('====================================================');
  console.log('       STARTING COMPSTOCK INTEGRATION TESTS         ');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`[PASS] ${message}`);
      passed++;
    } else {
      console.error(`[FAIL] ${message}`);
      failed++;
    }
  }

  // 1. Authentication & Roles
  console.log('--- TEST GROUP 1: AUTHENTICATION & ROLES ---');
  const adminLogin = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/auth/login',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, { email: 'admin@compstock.lk', password: 'admin123' });

  assert(adminLogin.status === 200, 'Admin login HTTP 200');
  assert(adminLogin.data.user && adminLogin.data.user.role === 'admin', 'Admin role authenticated');
  const adminToken = adminLogin.data.token;

  const staffLogin = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/auth/login',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, { email: 'staff@compstock.lk', password: 'staff123' });

  assert(staffLogin.status === 200, 'Sales staff login HTTP 200');
  assert(staffLogin.data.user && staffLogin.data.user.role === 'sales', 'Sales Staff role authenticated');
  const staffToken = staffLogin.data.token;

  // Authorization checks
  const staffCreateProd = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/products',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${staffToken}`
    }
  }, { name: 'Unauthorized Item', sku: 'UNAUTH-01', category: 'Sensors', selling_price: 100 });
  assert(staffCreateProd.status === 403, 'Sales staff blocked from adding products (HTTP 403)');

  const staffAudit = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/audit',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${staffToken}` }
  });
  assert(staffAudit.status === 403, 'Sales staff blocked from audit logs (HTTP 403)');

  // 2. Inventory & Stock Management (100+ items, barcode, valuation)
  console.log('\n--- TEST GROUP 2: INVENTORY & STOCK MANAGEMENT ---');
  const productsRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/products?limit=200',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(productsRes.status === 200, 'Fetch products list HTTP 200');
  assert(productsRes.data.products && productsRes.data.products.length >= 100, `Over 100 products seeded in catalog (Found: ${productsRes.data.products?.length})`);

  const valuationRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/products/valuation',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(valuationRes.status === 200, 'Inventory valuation endpoint HTTP 200');
  assert(valuationRes.data.valuation.asset_value_cost > 0 && valuationRes.data.valuation.retail_value > 0, 'Valuation cost and retail values computed');

  // Barcode lookup
  const sampleBarcode = productsRes.data.products.find(p => p.barcode)?.barcode || '890100100001';
  const barcodeRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/products/barcode/${sampleBarcode}`,
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(barcodeRes.status === 200 && barcodeRes.data.product, `Barcode lookup for "${sampleBarcode}" succeeded`);

  // Global search
  const searchRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/products/global-search?q=ESP32',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(searchRes.status === 200 && searchRes.data.products.length > 0, 'Global search returns matching products');

  // Stock movement & history
  const testProduct = productsRes.data.products[0];
  const historyRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/products/${testProduct.id}/history`,
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(historyRes.status === 200 && Array.isArray(historyRes.data.history), 'Product stock movement history retrieved');

  // Categories list & new category product registration without icon style
  const catsRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/products/categories',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(catsRes.status === 200 && Array.isArray(catsRes.data.categories), 'Categories endpoint HTTP 200');
  assert(catsRes.data.categories.includes('Microcontrollers'), 'Categories list contains existing categories');

  // Register product with a brand new custom category without icon style
  const uniqueCategoryName = `Custom Solar & Power-${Date.now()}`;
  const newCatProdRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/products',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${adminToken}`
    }
  }, {
    name: 'High Efficiency Solar Cell 5V',
    category: uniqueCategoryName,
    selling_price: 650,
    cost_price: 380,
    stock_quantity: 15
  });
  assert(newCatProdRes.status === 201, 'Product with new custom category registered without icon (HTTP 201)');
  assert(newCatProdRes.data.product.category === uniqueCategoryName, 'Product saved under new custom category');
  assert(['cpu', 'chip', 'res', 'sen', 'disp'].includes(newCatProdRes.data.product.icon), 'Icon automatically resolved without requiring user selection');

  // Verify the new category is now dynamically returned in categories list
  const catsAfterRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/products/categories',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(catsAfterRes.data.categories.includes(uniqueCategoryName), 'Newly added custom category is persisted in categories list');

  // 3. Customer Management
  console.log('\n--- TEST GROUP 3: CUSTOMER MANAGEMENT ---');
  const testPhone = `077${Math.floor(1000000 + Math.random() * 9000000)}`;
  const createCustRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/customers',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${adminToken}`
    }
  }, {
    name: 'Dilshan Silva',
    phone: testPhone,
    email: 'dilshan.silva@example.lk',
    company: 'Silva IoT Robotics',
    address: 'Kandy Road, Kelaniya'
  });
  assert(createCustRes.status === 201, 'Customer created successfully (HTTP 201)');
  assert(createCustRes.data.customer.status === 'active', 'Customer default status is active');
  const customerId = createCustRes.data.customer.id;

  const updateCustRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/customers/${customerId}`,
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${adminToken}`
    }
  }, {
    name: 'Dilshan Silva (Updated)',
    phone: testPhone,
    status: 'inactive'
  });
  assert(updateCustRes.status === 200 && updateCustRes.data.customer.status === 'inactive', 'Customer status updated to inactive');

  // Reactivate customer for sales
  await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/customers/${customerId}`,
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${adminToken}`
    }
  }, {
    name: 'Dilshan Silva',
    phone: testPhone,
    status: 'active'
  });

  const getCustPurchases = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/customers/${customerId}/purchases`,
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(getCustPurchases.status === 200, 'Customer purchase history endpoint HTTP 200');

  // 4. Sales POS & Checkout (Discounts & Cash Change, Strictly No Tax)
  console.log('\n--- TEST GROUP 4: SALES POS, DISCOUNTS & BALANCE (NO TAX) ---');
  const targetProd = productsRes.data.products.find(p => p.stock_quantity >= 5);
  const initialStock = targetProd.stock_quantity;

  // Test overselling protection
  const overSellRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/sales',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${staffToken}`
    }
  }, {
    customer_id: customerId,
    payment_method: 'cash',
    items: [
      { product_id: targetProd.id, quantity: 999999 }
    ]
  });
  assert(overSellRes.status === 400, 'Overselling rejected with HTTP 400');

  const saleRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/sales',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${staffToken}`
    }
  }, {
    customer_id: customerId,
    payment_method: 'cash',
    discount_type: 'percentage',
    discount_rate: 10,
    amount_paid: 10000,
    items: [
      { product_id: targetProd.id, quantity: 2 }
    ]
  });

  assert(saleRes.status === 201, 'Sale completed with customer and 10% discount (HTTP 201)');
  assert(saleRes.data.sale && saleRes.data.sale.invoice_number, 'Invoice number generated');
  const createdSale = saleRes.data.sale;
  assert(createdSale.tax === 0, 'Tax is strictly 0 (No VAT/Tax)');
  assert(createdSale.total === (createdSale.subtotal - createdSale.discount), 'Formula verified: Subtotal - Discount = Final Total');
  assert(createdSale.change_amount >= 0, 'Change amount computed correctly');

  // Verify stock decremented by 2
  const updatedProd = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/products/${targetProd.id}`,
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(updatedProd.data.product.stock_quantity === initialStock - 2, `Inventory decremented from ${initialStock} to ${initialStock - 2}`);

  // 5. Sales Returns & Refunds
  console.log('\n--- TEST GROUP 5: SALES RETURNS & RESTORATION ---');
  const returnRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/returns',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${staffToken}`
    }
  }, {
    invoice_number: createdSale.invoice_number,
    reason: 'Customer requested component exchange',
    items: [
      { sale_item_id: createdSale.items[0].id, quantity: 1 }
    ]
  });
  assert(returnRes.status === 201, 'Return processed successfully (HTTP 201)');
  assert(returnRes.data.return && returnRes.data.return.return_number, 'Return number generated');

  // Verify stock restored by 1
  const restoredProd = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/products/${targetProd.id}`,
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(restoredProd.data.product.stock_quantity === initialStock - 1, `Inventory restored by 1 (Now: ${restoredProd.data.product.stock_quantity})`);

  // Verify invoice return status
  const saleStatusCheck = await request({
    hostname: 'localhost',
    port: 3000,
    path: `/api/sales/${createdSale.id}`,
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(saleStatusCheck.data.sale.return_status === 'partial', 'Invoice return_status updated to partial');

  // 6. Profit & Margin Reports & Stock Forecasting
  console.log('\n--- TEST GROUP 6: PROFIT ANALYTICS & STOCK FORECASTING ---');
  const dashReport = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/reports/dashboard',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(dashReport.status === 200, 'Dashboard KPIs endpoint HTTP 200');
  assert(dashReport.data.today_profit !== undefined, 'Dashboard includes profit KPI');

  const forecastsRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/reports/forecasts',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(forecastsRes.status === 200 && forecastsRes.data.forecasts.length >= 100, 'Stock forecasts computed for all components');
  assert(forecastsRes.data.forecasts[0].days_remaining !== undefined, 'Forecasting computes days remaining based on demand');

  const calendarRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/reports/calendar',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(calendarRes.status === 200 && Array.isArray(calendarRes.data.days), 'Sales calendar data retrieved');

  // 7. Smart Notifications
  console.log('\n--- TEST GROUP 7: SMART NOTIFICATIONS ---');
  const notifsRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/notifications',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(notifsRes.status === 200 && Array.isArray(notifsRes.data.notifications), 'Notifications center endpoint HTTP 200');
  assert(notifsRes.data.notifications.length > 0, 'Notifications generated from live database alerts');

  // 8. Audit Logs & System Settings & Backup
  console.log('\n--- TEST GROUP 8: AUDIT TRAILS, SETTINGS & BACKUP ---');
  const auditRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/audit?limit=20',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(auditRes.status === 200 && auditRes.data.logs.length > 0, 'Audit trail logs retrieved');

  const backupStats = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/backup/stats',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(backupStats.status === 200 && backupStats.data.database.size_bytes > 0, 'Database backup diagnostics returned');

  const snapshotRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/backup/snapshot',
    method: 'POST',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(snapshotRes.status === 201 && snapshotRes.data.snapshot.filename, 'Database snapshot created successfully');

  // 9. CSV Exports
  console.log('\n--- TEST GROUP 9: CLEAN CSV EXPORTS ---');
  const csvDaily = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/export/csv?type=daily',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(csvDaily.status === 200 && csvDaily.headers['content-type'].includes('text/csv'), 'Daily sales CSV export HTTP 200');

  const csvForecasts = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/export/csv?type=forecasts',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(csvForecasts.status === 200 && csvForecasts.headers['content-type'].includes('text/csv'), 'Forecasting CSV export HTTP 200');

  // 10. User Registration & Auth Validation
  console.log('\n--- TEST GROUP 10: REGISTRATION & AUTH VALIDATION ---');
  const testEmail = `testuser_${Date.now()}@compstock.lk`;
  const registerRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/auth/register',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, {
    name: 'Kasun Chamara',
    email: testEmail,
    password: 'Password@123'
  });
  assert(registerRes.status === 201 && registerRes.data.success, 'User self-registration HTTP 201');
  assert(registerRes.data.user && registerRes.data.user.role === 'sales', 'New user assigned Normal User (sales) role');

  const duplicateRegister = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/auth/register',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, {
    name: 'Kasun Duplicate',
    email: testEmail,
    password: 'Password@123'
  });
  assert(duplicateRegister.status === 400, 'Duplicate email registration rejected with HTTP 400');

  // 11. Swagger OpenAPI & React Assets
  console.log('\n--- TEST GROUP 11: OPENAPI SWAGGER & REACT ASSETS ---');
  const swaggerDocsRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api-docs.json',
    method: 'GET'
  });
  assert(swaggerDocsRes.status === 200 && swaggerDocsRes.data.openapi === '3.0.0', 'OpenAPI 3.0 specification served at /api-docs.json');

  const reactBundleRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/dist/bundle.js',
    method: 'GET'
  });
  assert(reactBundleRes.status === 200, 'Compiled React 18 production bundle served at /dist/bundle.js');

  // 12. Direct Binary PDF Report Downloads
  console.log('\n--- TEST GROUP 12: BINARY PDF REPORT DOWNLOADS ---');
  const dailyPdfRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/export/pdf?type=daily',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(dailyPdfRes.status === 200 && dailyPdfRes.headers['content-type'].includes('application/pdf'), 'Daily PDF report download HTTP 200');

  const monthlyPdfRes = await request({
    hostname: 'localhost',
    port: 3000,
    path: '/api/export/pdf?type=monthly',
    method: 'GET',
    headers: { 'Authorization': `Bearer ${adminToken}` }
  });
  assert(monthlyPdfRes.status === 200 && monthlyPdfRes.headers['content-type'].includes('application/pdf'), 'Monthly PDF report download HTTP 200');

  console.log('\n====================================================');
  console.log(`TEST SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('====================================================');

  process.exit(failed > 0 ? 1 : 0);
}

runTests().catch(err => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
