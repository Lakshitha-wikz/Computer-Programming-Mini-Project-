/**
 * CompStock 14-Step Complete Workflow Verification Test
 * Tests all 14 requirements specified in IA 3208 Section 9:
 * 1. Add a new product.
 * 2. Search for the newly added product.
 * 3. Edit product information.
 * 4. Select the product on the POS page.
 * 5. Add products to the cart.
 * 6. Change product quantities.
 * 7. Select a customer.
 * 8. Change the selected customer before payment.
 * 9. Complete a sale.
 * 10. Generate a receipt.
 * 11. Verify stock reduction.
 * 12. Verify sales reports.
 * 13. Verify product cost and profit calculations.
 * 14. Verify search functionality on all relevant pages.
 */

const assert = require('assert');
const http = require('http');

const PORT = 3000;
let adminCookie = '';
let salesCookie = '';

function request(method, path, body = null, cookie = '') {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: PORT,
      path,
      method,
      headers: {
        'Content-Type': 'application/json'
      }
    };
    if (cookie) options.headers['Cookie'] = cookie;

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        let json = null;
        try {
          json = JSON.parse(data);
        } catch (e) {
          json = data;
        }
        resolve({
          status: res.statusCode,
          headers: res.headers,
          data: json
        });
      });
    });

    req.on('error', reject);
    if (body) {
      req.write(typeof body === 'string' ? body : JSON.stringify(body));
    }
    req.end();
  });
}

async function ensureServerRunning() {
  try {
    await request('GET', '/api/auth/me');
  } catch (err) {
    console.log('Spawning application server for workflow testing...');
    require('../server.js');
    await new Promise(r => setTimeout(r, 1200));
  }
}

async function run14StepWorkflows() {
  await ensureServerRunning();

  console.log('====================================================');
  console.log('  STARTING COMPSTOCK 14-STEP WORKFLOW VERIFICATION  ');
  console.log('====================================================\n');

  // Login as admin
  const adminLogin = await request('POST', '/api/auth/login', {
    email: 'admin@compstock.lk',
    password: 'admin123'
  });
  assert.strictEqual(adminLogin.status, 200, 'Admin login failed');
  adminCookie = adminLogin.headers['set-cookie'][0].split(';')[0];
  console.log('[AUTH] Admin authenticated successfully');

  // Login as sales staff
  const staffLogin = await request('POST', '/api/auth/login', {
    email: 'staff@compstock.lk',
    password: 'staff123'
  });
  assert.strictEqual(staffLogin.status, 200, 'Staff login failed');
  salesCookie = staffLogin.headers['set-cookie'][0].split(';')[0];
  console.log('[AUTH] Staff authenticated successfully\n');

  // --- WORKFLOW 1: Add a new product ---
  console.log('--- WORKFLOW 1: Add a new product ---');
  const timestamp = Date.now();
  const testSku = `TST-${timestamp}`;
  const testBarcode = `999${String(timestamp).slice(-9)}`;
  const newProductPayload = {
    name: 'STM32F401 Black Pill Development Board',
    sku: testSku,
    barcode: testBarcode,
    category: 'Development Boards',
    supplier: 'Lanka Robotics & Electronics',
    description: 'Arm Cortex-M4 84MHz 256KB Flash 64KB RAM with USB-C',
    selling_price: 2450.00,
    cost_price: 1500.00,
    stock_quantity: 40,
    low_stock_threshold: 6,
    icon: 'cpu'
  };

  const addRes = await request('POST', '/api/products', newProductPayload, adminCookie);
  assert.strictEqual(addRes.status, 201, 'Failed to add product (HTTP 201 expected)');
  const createdProduct = addRes.data.product;
  assert.ok(createdProduct && createdProduct.id, 'Product object not returned');
  assert.strictEqual(createdProduct.sku, testSku, 'SKU mismatch');
  assert.strictEqual(createdProduct.supplier, 'Lanka Robotics & Electronics', 'Supplier mismatch');
  assert.strictEqual(createdProduct.stock_quantity, 40, 'Stock mismatch');
  console.log(`[PASS] Workflow 1: Created product ID #${createdProduct.id} (${createdProduct.name}) with Supplier "${createdProduct.supplier}"`);

  // Verify duplicate SKU rejection
  const dupRes = await request('POST', '/api/products', newProductPayload, adminCookie);
  assert.strictEqual(dupRes.status, 400, 'Duplicate SKU not rejected');
  console.log('[PASS] Workflow 1: Duplicate SKU prevented correctly (HTTP 400)');

  // --- WORKFLOW 2: Search for the newly added product ---
  console.log('\n--- WORKFLOW 2: Search for the newly added product ---');
  // 2a. Search by SKU
  const searchSkuRes = await request('GET', `/api/products?search=${encodeURIComponent(testSku)}`, null, adminCookie);
  assert.strictEqual(searchSkuRes.status, 200);
  assert.ok(searchSkuRes.data.products.some(p => p.id === createdProduct.id), 'Search by SKU failed');

  // 2b. Search by Barcode
  const searchBcRes = await request('GET', `/api/products?search=${encodeURIComponent(testBarcode)}`, null, adminCookie);
  assert.strictEqual(searchBcRes.status, 200);
  assert.ok(searchBcRes.data.products.some(p => p.id === createdProduct.id), 'Search by Barcode failed');

  // 2c. Search by Name
  const searchNameRes = await request('GET', `/api/products?search=${encodeURIComponent('Black Pill')}`, null, adminCookie);
  assert.strictEqual(searchNameRes.status, 200);
  assert.ok(searchNameRes.data.products.some(p => p.id === createdProduct.id), 'Search by Name failed');
  console.log('[PASS] Workflow 2: Newly added product found via Name, SKU, and Barcode search');

  // --- WORKFLOW 3: Edit product information ---
  console.log('\n--- WORKFLOW 3: Edit product information ---');
  const editPayload = {
    name: 'STM32F401 Black Pill Development Board V2',
    sku: testSku,
    barcode: testBarcode,
    category: 'Development Boards',
    supplier: 'Lanka Robotics & Electronics Group',
    description: 'Updated with USB-C OTG & Dual Crystal',
    selling_price: 2600.00,
    cost_price: 1550.00,
    low_stock_threshold: 8,
    icon: 'cpu',
    status: 'active'
  };
  const editRes = await request('PUT', `/api/products/${createdProduct.id}`, editPayload, adminCookie);
  assert.strictEqual(editRes.status, 200, 'Failed to edit product');
  assert.strictEqual(editRes.data.product.selling_price, 2600.00, 'Selling price not updated');
  assert.strictEqual(editRes.data.product.cost_price, 1550.00, 'Cost price not updated');
  assert.strictEqual(editRes.data.product.supplier, 'Lanka Robotics & Electronics Group', 'Supplier not updated');
  console.log(`[PASS] Workflow 3: Product #${createdProduct.id} updated (Price: Rs 2450 → Rs 2600, Cost: Rs 1500 → Rs 1550)`);

  // --- WORKFLOW 4: Select the product on the POS page ---
  console.log('\n--- WORKFLOW 4: Select the product on the POS page ---');
  const posCatalogRes = await request('GET', '/api/products?status=active', null, salesCookie);
  assert.strictEqual(posCatalogRes.status, 200);
  const posItem = posCatalogRes.data.products.find(p => p.id === createdProduct.id);
  assert.ok(posItem, 'New product not visible in active POS catalog');
  assert.strictEqual(posItem.stock_quantity, 40, 'Available stock mismatch');
  console.log(`[PASS] Workflow 4: Product "${posItem.name}" is selectable in POS with stock = ${posItem.stock_quantity}`);

  // --- WORKFLOW 5: Add products to the cart ---
  console.log('\n--- WORKFLOW 5: Add products to the cart ---');
  // Client simulation: cart holds 2 units of the new product
  let simCart = [
    {
      product_id: posItem.id,
      name: posItem.name,
      sku: posItem.sku,
      unit_price: posItem.selling_price,
      unit_cost: posItem.cost_price,
      quantity: 2
    }
  ];
  let subtotal = simCart.reduce((sum, it) => sum + (it.unit_price * it.quantity), 0);
  assert.strictEqual(subtotal, 5200.00, 'Cart subtotal calculation error');
  console.log(`[PASS] Workflow 5: Added 2 units to cart (Subtotal: Rs ${subtotal.toLocaleString()})`);

  // --- WORKFLOW 6: Change product quantities ---
  console.log('\n--- WORKFLOW 6: Change product quantities ---');
  // Change quantity to 3
  simCart[0].quantity = 3;
  subtotal = simCart.reduce((sum, it) => sum + (it.unit_price * it.quantity), 0);
  assert.strictEqual(subtotal, 7800.00, 'Cart subtotal after quantity change error');
  console.log(`[PASS] Workflow 6: Updated quantity to 3 (New Subtotal: Rs ${subtotal.toLocaleString()})`);

  // --- WORKFLOW 7: Select a customer ---
  console.log('\n--- WORKFLOW 7: Select a customer ---');
  const custRes = await request('GET', '/api/customers', null, salesCookie);
  assert.strictEqual(custRes.status, 200);
  const customer1 = custRes.data.customers[0];
  const customer2 = custRes.data.customers[1] || customer1;
  assert.ok(customer1, 'No active customers found');
  console.log(`[PASS] Workflow 7: Customer 1 selected: "${customer1.name}" (ID #${customer1.id})`);

  // --- WORKFLOW 8: Change the selected customer before payment ---
  console.log('\n--- WORKFLOW 8: Change the selected customer before payment ---');
  // Simulating changing from customer1 to customer2
  let activeSelectedCustomerId = customer1.id;
  let activeSelectedCustomerName = customer1.name;

  // Change to customer2
  activeSelectedCustomerId = customer2.id;
  activeSelectedCustomerName = customer2.name;
  console.log(`[PASS] Workflow 8a: Customer changed to: "${activeSelectedCustomerName}" (ID #${activeSelectedCustomerId})`);

  // Test reverting to Walk-in Customer
  activeSelectedCustomerId = null;
  activeSelectedCustomerName = 'Walk-in Customer';
  console.log(`[PASS] Workflow 8b: Customer cleared / reverted to "${activeSelectedCustomerName}"`);

  // Finally select customer1 for the completed sale
  activeSelectedCustomerId = customer1.id;
  activeSelectedCustomerName = customer1.name;
  console.log(`[PASS] Workflow 8c: Final customer set to: "${activeSelectedCustomerName}"`);

  // --- WORKFLOW 9: Complete a sale ---
  console.log('\n--- WORKFLOW 9: Complete a sale ---');
  // Subtotal = 7800, Discount = 300, Final Total = 7500 (No VAT/Tax)
  const discountAmount = 300;
  const grandTotal = subtotal - discountAmount;
  const amountTendered = 8000;
  const changeExpected = amountTendered - grandTotal; // 500

  const salePayload = {
    customer_id: activeSelectedCustomerId,
    customer_name: activeSelectedCustomerName,
    payment_method: 'cash',
    payment_status: 'paid',
    discount_type: 'fixed',
    discount: discountAmount,
    amount_paid: amountTendered,
    items: simCart.map(it => ({
      product_id: it.product_id,
      quantity: it.quantity
    }))
  };

  const saleRes = await request('POST', '/api/sales', salePayload, salesCookie);
  assert.strictEqual(saleRes.status, 201, 'Failed to complete sale');
  const completedSale = saleRes.data.sale;
  assert.ok(completedSale && completedSale.id, 'Sale not created');
  assert.strictEqual(completedSale.customer_id, customer1.id, 'Customer ID not recorded');
  assert.strictEqual(completedSale.total, 7500, 'Sale total mismatch');
  assert.strictEqual(completedSale.tax, 0, 'Tax must strictly be 0 (No VAT/Tax)');
  assert.strictEqual(completedSale.change_amount, 500, 'Change amount mismatch');
  console.log(`[PASS] Workflow 9: Sale completed! Invoice #${completedSale.invoice_number} (Total: Rs ${completedSale.total}, Change: Rs ${completedSale.change_amount})`);

  // --- WORKFLOW 10: Generate a receipt ---
  console.log('\n--- WORKFLOW 10: Generate a receipt ---');
  const invoiceRes = await request('GET', `/api/sales/${completedSale.id}`, null, salesCookie);
  assert.strictEqual(invoiceRes.status, 200, 'Failed to retrieve invoice details');
  const receipt = invoiceRes.data.sale;
  assert.ok(receipt.items && receipt.items.length === 1, 'Receipt items missing');
  assert.strictEqual(receipt.items[0].product_id, posItem.id, 'Receipt item mismatch');
  assert.strictEqual(receipt.items[0].unit_cost, 1550, 'Sale-time unit cost not preserved');
  console.log(`[PASS] Workflow 10: Receipt generated for Invoice #${receipt.invoice_number} with unit cost Rs ${receipt.items[0].unit_cost}`);

  // --- WORKFLOW 11: Verify stock reduction ---
  console.log('\n--- WORKFLOW 11: Verify stock reduction ---');
  const stockCheck = await request('GET', `/api/products/${posItem.id}`, null, adminCookie);
  assert.strictEqual(stockCheck.status, 200);
  const newStock = stockCheck.data.product.stock_quantity;
  // Starting was 40, sold 3 -> should now be 37
  assert.strictEqual(newStock, 37, `Stock should be 37, got ${newStock}`);
  console.log(`[PASS] Workflow 11: Stock reduced atomically from 40 to ${newStock} units`);

  // --- WORKFLOW 12: Verify sales reports ---
  console.log('\n--- WORKFLOW 12: Verify sales reports ---');
  const reportRes = await request('GET', '/api/reports/sales?period=today', null, adminCookie);
  assert.strictEqual(reportRes.status, 200);
  const kpis = reportRes.data.kpis;
  assert.ok(kpis.revenue >= 7500, 'Report revenue does not include latest sale');
  assert.ok(kpis.transactions >= 1, 'Transaction count invalid');
  console.log(`[PASS] Workflow 12: Sales report verified (Today Revenue: Rs ${kpis.revenue.toLocaleString()}, Transactions: ${kpis.transactions})`);

  // --- WORKFLOW 13: Verify product cost and profit calculations ---
  console.log('\n--- WORKFLOW 13: Verify product cost and profit calculations ---');
  // Formula check on this sale:
  // Selling Revenue = 7500 (3 * 2600 = 7800 - 300 discount)
  // Product Cost = 3 * 1550 = 4650
  // Gross Profit = 7500 - 4650 = 2850
  // Profit Margin (%) = (2850 / 7500) * 100 = 38%
  const reportedSale = reportRes.data.sales.find(s => s.id === completedSale.id);
  assert.ok(reportedSale, 'Sale not found in reports list');
  assert.strictEqual(reportedSale.order_cost, 4650, `Order cost mismatch: expected 4650, got ${reportedSale.order_cost}`);
  assert.strictEqual(reportedSale.order_profit, 2850, `Order profit mismatch: expected 2850, got ${reportedSale.order_profit}`);
  const marginPct = Math.round((reportedSale.order_profit / reportedSale.total) * 100);
  assert.strictEqual(marginPct, 38, `Margin mismatch: expected 38%, got ${marginPct}%`);
  console.log(`[PASS] Workflow 13: Cost & Profit verified (Order Cost: Rs ${reportedSale.order_cost}, Profit: Rs ${reportedSale.order_profit}, Margin: ${marginPct}%)`);

  // --- WORKFLOW 14: Verify search functionality on all relevant pages ---
  console.log('\n--- WORKFLOW 14: Verify search functionality on all relevant pages ---');
  // 14a. Global Topbar Search
  const globalSearchRes = await request('GET', `/api/products/global-search?q=${encodeURIComponent('STM32F401')}`, null, adminCookie);
  assert.strictEqual(globalSearchRes.status, 200);
  assert.ok(globalSearchRes.data.products.some(p => p.sku === testSku), 'Global search did not find product');
  console.log('[PASS] Workflow 14a: Topbar Global search works');

  // 14b. POS Catalog Search
  const posSearchRes = await request('GET', `/api/products?search=${encodeURIComponent('Black Pill')}&status=active`, null, salesCookie);
  assert.strictEqual(posSearchRes.status, 200);
  assert.ok(posSearchRes.data.products.some(p => p.sku === testSku), 'POS search did not find product');
  console.log('[PASS] Workflow 14b: POS Sales page search works');

  // 14c. Invoices List Search
  const invSearchRes = await request('GET', `/api/sales?search=${encodeURIComponent(completedSale.invoice_number)}`, null, salesCookie);
  assert.strictEqual(invSearchRes.status, 200);
  assert.ok(invSearchRes.data.sales.some(s => s.id === completedSale.id), 'Invoices search did not find invoice');
  console.log('[PASS] Workflow 14c: Invoices list search works');

  // 14d. Customer Search
  const custSearchRes = await request('GET', `/api/customers?search=${encodeURIComponent(customer1.name)}`, null, salesCookie);
  assert.strictEqual(custSearchRes.status, 200);
  assert.ok(custSearchRes.data.customers.some(c => c.id === customer1.id), 'Customer search did not find customer');
  console.log('[PASS] Workflow 14d: Customer directory search works');

  console.log('\n====================================================');
  console.log('  ALL 14 COMPSTOCK WORKFLOWS VERIFIED SUCCESSFULLY  ');
  console.log('====================================================');
}

run14StepWorkflows()
  .then(() => process.exit(0))
  .catch(err => {
    console.error('\n[WORKFLOW TEST FAILED]:', err.message);
    console.error(err.stack);
    process.exit(1);
  });
