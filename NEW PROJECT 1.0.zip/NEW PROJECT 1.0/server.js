
// ==========================================
// Environment Variables Load කිරීම
// ==========================================

// .env File එකේ තියෙන Environment Variables ලබාගැනීම
require('dotenv').config();

// ==========================================
// Required Modules Import කිරීම
// ==========================================

// Express Framework එක Import කිරීම
const express = require('express');

// File Paths නිර්මාණය කිරීමට path Module එක
const path = require('path');

// Files තිබෙනවාද නැද්ද පරීක්ෂා කිරීමට fs Module එක
const fs = require('fs');

// System Commands Execute කිරීමට execSync ලබාගැනීම
const { execSync } = require('child_process');

// Cookies කියවීමට cookie-parser Import කිරීම
const cookieParser = require('cookie-parser');

// Cross-Origin Requests සඳහා CORS Import කිරීම
const cors = require('cors');

// Swagger API Documentation සඳහා Swagger UI Import කිරීම
const swaggerUi = require('swagger-ui-express');

// Swagger Documentation Configuration එක Import කිරීම
const swaggerSpec = require('./docs/swagger');

// Application Logs කළමනාකරණය කිරීමට Logger Import කිරීම
const logger = require('./utils/logger');


// ==========================================
// API Routes Import කිරීම
// ==========================================

// Authentication සම්බන්ධ API Routes
const authRoutes = require('./routes/auth');

// Product Management API Routes
const productRoutes = require('./routes/products');

// Sales Management API Routes
const salesRoutes = require('./routes/sales');

// Returns Management API Routes
const returnsRoutes = require('./routes/returns');

// Customer Management API Routes
const customerRoutes = require('./routes/customers');

// Notifications API Routes
const notificationRoutes = require('./routes/notifications');

// Reports API Routes
const reportRoutes = require('./routes/reports');

// Audit Logs API Routes
const auditRoutes = require('./routes/audit');

// System Settings API Routes
const settingsRoutes = require('./routes/settings');

// Database Backup API Routes
const backupRoutes = require('./routes/backup');

// User Management API Routes
const userRoutes = require('./routes/users');

// Data Export API Routes
const exportRoutes = require('./routes/export');

// Database එකට Initial Data ඇතුළත් කිරීමට seedDatabase Import කිරීම
const { seedDatabase } = require('./database/seed');

// Database එකෙන් එක් Result එකක් ලබාගැනීමට queryOne Import කිරීම
const { queryOne } = require('./database/db');


// ==========================================
// Express Application එක නිර්මාණය කිරීම
// ==========================================

// Express Application එක Create කිරීම
const app = express();

// .env File එකේ PORT එක තිබේ නම් එය භාවිතා කිරීම
// PORT එකක් නොමැති නම් Default Port එක ලෙස 3000 භාවිතා කිරීම
const PORT = process.env.PORT || 3000;


// ==========================================
// Database Initialization සහ Seed Data
// ==========================================

// Database එකේ Users සිටිනවාදැයි පරීක්ෂා කිරීම
try {
  const userCount = queryOne('SELECT COUNT(*) as c FROM users');

  // Users කිසිවෙකු නොමැති නම් Initial Data ඇතුළත් කිරීම
  if (!userCount || userCount.c === 0) {
    logger.info('Empty database detected on startup. Auto-seeding initial data...');
    seedDatabase(false);
  }

// Database එක පරීක්ෂා කිරීමේදී Error එකක් ඇති වුවහොත්
} catch (e) {
  logger.info('Running initial database seed...');

  // Initial Database Data ඇතුළත් කිරීම
  seedDatabase(false);
}


// ==========================================
// React Frontend Bundle එක පරීක්ෂා කිරීම
// ==========================================

// React Application එකේ Production Bundle File එකේ Path එක ලබාගැනීම
const bundlePath = path.join(__dirname, 'public', 'dist', 'bundle.js');

// Bundle File එක නොමැති නම් එය Compile කිරීම
if (!fs.existsSync(bundlePath)) {
  try {
    logger.info('Compiling React SPA application bundle with esbuild...');

    // React JSX Code එක Bundle එකක් බවට Compile කිරීම
    execSync('npx esbuild src/index.jsx --bundle --outfile=public/dist/bundle.js --loader:.js=jsx', { stdio: 'inherit' });

    logger.info('React bundle compiled successfully.');

  // Bundle එක Compile කිරීමේදී Error එකක් ඇති වුවහොත්
  } catch (err) {
    logger.error('Failed to auto-compile React bundle:', err);
  }
}


// ==========================================
// Global Middleware
// ==========================================

// වෙනත් Origins වලින් එන Requests සඳහා CORS සකස් කිරීම
app.use(cors());

// Frontend එකෙන් එන JSON Request Body එක කියවීම
app.use(express.json());

// HTML Form Data කියවීමට Middleware එක භාවිතා කිරීම
app.use(express.urlencoded({ extended: true }));

// Request එකේ Cookies කියවීම
app.use(cookieParser());

// Backend එකට ලැබෙන Requests Log කිරීම
app.use(logger.requestLogger);


// ==========================================
// Static Frontend Files ලබාදීම
// ==========================================

// public Folder එකේ තියෙන Frontend Files Browser එකට ලබාදීම
app.use(express.static(path.join(__dirname, 'public')));


// ==========================================
// Swagger API Documentation
// ==========================================

// Swagger JSON Documentation ලබාදෙන API Endpoint එක
app.get('/api-docs.json', (req, res) => {

  // Response එකේ Content-Type එක JSON ලෙස සැකසීම
  res.setHeader('Content-Type', 'application/json');

  // Swagger Specification එක Frontend එකට යැවීම
  res.send(swaggerSpec);
});

// Swagger Interactive API Documentation ලබාදීම
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, {

  // Swagger Page එකේ Browser Title එක සැකසීම
  customSiteTitle: 'CompStock API Docs · IA 3208 Evaluation',

  // Swagger UI එකේ Top Bar එකට Custom CSS ලබාදීම
  customCss: '.swagger-ui .topbar { background-color: #0f2038; }'
}));


// ==========================================
// API Routes Register කිරීම
// ==========================================

// Authentication Requests /api/auth Route එකට යොමු කිරීම
app.use('/api/auth', authRoutes);

// Product Requests /api/products Route එකට යොමු කිරීම
app.use('/api/products', productRoutes);

// Sales Requests /api/sales Route එකට යොමු කිරීම
app.use('/api/sales', salesRoutes);

// Returns Requests /api/returns Route එකට යොමු කිරීම
app.use('/api/returns', returnsRoutes);

// Customer Requests /api/customers Route එකට යොමු කිරීම
app.use('/api/customers', customerRoutes);

// Notification Requests /api/notifications Route එකට යොමු කිරීම
app.use('/api/notifications', notificationRoutes);

// Reports Requests /api/reports Route එකට යොමු කිරීම
app.use('/api/reports', reportRoutes);

// Audit Requests /api/audit Route එකට යොමු කිරීම
app.use('/api/audit', auditRoutes);

// Settings Requests /api/settings Route එකට යොමු කිරීම
app.use('/api/settings', settingsRoutes);

// Backup Requests /api/backup Route එකට යොමු කිරීම
app.use('/api/backup', backupRoutes);

// User Requests /api/users Route එකට යොමු කිරීම
app.use('/api/users', userRoutes);

// Export Requests /api/export Route එකට යොමු කිරීම
app.use('/api/export', exportRoutes);


// ==========================================
// Frontend SPA Fallback
// ==========================================

// ඉහත Routes වලට ගැළපෙන්නේ නැති GET Requests Handle කිරීම
app.get('*', (req, res) => {

  // නොපවතින API Endpoint එකක් නම් 404 Error එකක් යැවීම
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API endpoint not found' });
  }

  // අනෙකුත් Frontend Requests සඳහා index.html ලබාදීම
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


// ==========================================
// Central Error Handler
// ==========================================

// Backend එකේ ඇතිවන Errors Handle කිරීම සඳහා
app.use((err, req, res, next) => {

  // Error එක Logger එක හරහා Log කිරීම
  logger.error('Unhandled server error:', err);

  // Error Status Code එක සහ Error Message එක JSON ලෙස යැවීම
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error'
  });
});


// ==========================================
// Backend Server එක Start කිරීම
// ==========================================

// Application එක Test Mode එකේ නොමැති විට පමණක් Server එක Start කිරීම
if (process.env.NODE_ENV !== 'test') {

  // ලබාදී ඇති PORT එකේ Server එක Listen කිරීම
  app.listen(PORT, () => {

    // Server එක සාර්ථකව Start වූ බව Console එකේ පෙන්වීම
    logger.info(`====================================================`);
    logger.info(`  CompStock Server running at http://localhost:${PORT}`);

    // Swagger Documentation URL එක පෙන්වීම
    logger.info(`  Interactive Swagger Docs: http://localhost:${PORT}/api-docs`);

    // දැනට ක්‍රියාත්මක Environment එක පෙන්වීම
    logger.info(`  Environment: ${process.env.NODE_ENV || 'development'}`);

    logger.info(`====================================================`);
  });
}


// ==========================================
// Export Express Application
// ==========================================

// වෙනත් Files සහ Automated Tests සඳහා Express Application එක Export කිරීම
module.exports = app;
