﻿function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ 
        error: 'Forbidden: You do not have permission to perform this action' 
      });
    }
    next();
  };
}

const requireAdmin = requireRole('admin');
const requireSalesOrAdmin = requireRole('admin', 'sales');

module.exports = {
  requireRole,
  requireAdmin,
  requireSalesOrAdmin
};
