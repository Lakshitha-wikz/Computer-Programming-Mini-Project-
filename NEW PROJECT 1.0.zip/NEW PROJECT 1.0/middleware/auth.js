﻿const jwt = require('jsonwebtoken');
const { queryOne } = require('../database/db');

const JWT_SECRET = process.env.JWT_SECRET || 'compstock_secure_key_2026_electronic_components';

function authenticateToken(req, res, next) {
  let token = null;

  // Check cookies first
  if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }
  // Check Authorization header
  else if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.substring(7);
  }

  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = queryOne('SELECT id, name, email, role, status FROM users WHERE id = ?', [decoded.id]);
    
    if (!user) {
      return res.status(401).json({ error: 'User no longer exists' });
    }
    if (user.status !== 'active') {
      return res.status(403).json({ error: 'Account is inactive or pending' });
    }

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired session token' });
  }
}

module.exports = {
  authenticateToken,
  JWT_SECRET
};
