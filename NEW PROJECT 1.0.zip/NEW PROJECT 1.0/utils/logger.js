const fs = require('fs');
const path = require('path');

const logsDir = path.resolve(__dirname, '../logs');
if (!fs.existsSync(logsDir)) {
  try {
    fs.mkdirSync(logsDir, { recursive: true });
  } catch (e) {
    // ignore
  }
}

const logFilePath = path.join(logsDir, 'app.log');

function formatTimestamp() {
  return new Date().toISOString();
}

function writeToFile(level, message, meta = null) {
  try {
    const timestamp = formatTimestamp();
    const metaStr = meta ? ` | ${typeof meta === 'object' ? JSON.stringify(sanitizeMeta(meta)) : meta}` : '';
    const logLine = `[${timestamp}] [${level}] ${message}${metaStr}\n`;
    fs.appendFileSync(logFilePath, logLine, 'utf8');
  } catch (err) {
    // Fail silently to avoid breaking execution
  }
}

function sanitizeMeta(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  const sanitized = { ...obj };
  const sensitiveKeys = ['password', 'password_hash', 'token', 'jwt', 'secret', 'authorization'];
  for (const key of Object.keys(sanitized)) {
    if (sensitiveKeys.includes(key.toLowerCase())) {
      sanitized[key] = '[REDACTED]';
    } else if (typeof sanitized[key] === 'object') {
      sanitized[key] = sanitizeMeta(sanitized[key]);
    }
  }
  return sanitized;
}

const logger = {
  info(message, meta = null) {
    const ts = formatTimestamp();
    console.log(`\x1b[36m[${ts}] [INFO]\x1b[0m ${message}`, meta ? meta : '');
    writeToFile('INFO', message, meta);
  },

  warn(message, meta = null) {
    const ts = formatTimestamp();
    console.warn(`\x1b[33m[${ts}] [WARN]\x1b[0m ${message}`, meta ? meta : '');
    writeToFile('WARN', message, meta);
  },

  error(message, errorOrMeta = null) {
    const ts = formatTimestamp();
    let meta = errorOrMeta;
    if (errorOrMeta instanceof Error) {
      meta = {
        name: errorOrMeta.name,
        message: errorOrMeta.message,
        stack: errorOrMeta.stack
      };
    }
    console.error(`\x1b[31m[${ts}] [ERROR]\x1b[0m ${message}`, meta ? meta : '');
    writeToFile('ERROR', message, meta);
  },

  // Express HTTP request logging middleware
  requestLogger(req, res, next) {
    const start = Date.now();
    res.on('finish', () => {
      const duration = Date.now() - start;
      const user = req.user ? `${req.user.name} (${req.user.role})` : 'Anonymous';
      const status = res.statusCode;
      const level = status >= 500 ? 'ERROR' : status >= 400 ? 'WARN' : 'INFO';
      const msg = `${req.method} ${req.originalUrl} HTTP ${status} - ${duration}ms [User: ${user}]`;

      if (level === 'ERROR') {
        logger.error(msg);
      } else if (level === 'WARN') {
        logger.warn(msg);
      } else {
        logger.info(msg);
      }
    });
    next();
  }
};

module.exports = logger;
