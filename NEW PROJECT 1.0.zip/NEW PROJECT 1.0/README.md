﻿# CompStock · Small Shop Inventory & Sales Management System
### University of Colombo · Faculty of Technology
**Course Code:** IA 3208 – Computer Programming Mini Project  
**Academic Year:** 2026/2027  
**Architecture:** React 18 Single Page Application (SPA) · Node.js / Express.js REST API · SQLite 3 Relational Database (WAL Mode)

---

## 1. Project Overview & Real-World Domain

**CompStock** is a full-stack, enterprise-grade Inventory and Point of Sale (POS) management system tailored for small electronic components, sensors, microcontrollers, and hobbyist hardware shops. 

It solves real-world retail inventory challenges by automating stock tracking, barcode lookup, POS checkout with atomic SQLite transactions, customer purchase history, returns restocking, and financial business reporting.

---

## 2. Technology Stack

### Frontend (Client-Side)
- **Framework:** **React 18** Single Page Application (SPA) with functional components and modern React hooks (`useState`, `useEffect`, `useRef`).
- **Styling:** Handcrafted **CSS3** design system with CSS Variables, Flexbox, CSS Grid, and dynamic **Dark/Light Mode** theming (`[data-theme="dark"]`).
- **Typography:** Space Grotesk (Brand & Headers), Inter (Body UI), JetBrains Mono (SKUs, Barcodes, Financial calculations).
- **Icons:** Scalable Vector Graphics (Inline SVG) for zero-latency, crisp rendering.
- **Bundler:** **esbuild** for high-speed production bundling (`npm run build`).

### Backend (Server-Side)
- **Runtime:** **Node.js** (v18+ / v22)
- **Web Framework:** **Express.js** (`v4.21.2`)
- **API Architecture:** RESTful API with standard JSON request/response formats (`GET`, `POST`, `PUT`, `DELETE`).
- **Authentication:** **JWT (JSON Web Tokens)** stored in secure `httpOnly` cookies with 7-day expiration.
- **Password Security:** **bcryptjs** (10 salt rounds) one-way cryptographic hashing.
- **Error Handling:** Centralized Express error handler with sanitized production error messages.
- **Logging:** Structured application logger (`utils/logger.js`) recording `[INFO]`, `[WARN]`, and `[ERROR]` events with timestamps to console and `logs/app.log`.

### Database (RDBMS)
- **Database Engine:** **SQLite 3** (`data/compstock.db`)
- **Driver:** Native Node.js `node:sqlite` (`DatabaseSync`)
- **Concurrency & Performance:** **WAL Mode (Write-Ahead Logging)** enabled (`PRAGMA journal_mode = WAL;`)
- **Integrity Constraints:** Foreign Keys strictly enforced (`PRAGMA foreign_keys = ON;`)
- **SQL Injection Prevention:** 100% Parameterized queries (Prepared Statements) across all routes.
- **Atomic Transactions:** Immediate transactions (`BEGIN IMMEDIATE` ... `COMMIT` / `ROLLBACK`) for POS checkout and return restocking.

### Reporting & Documentation
- **API Documentation:** Interactive **Swagger UI / OpenAPI 3.0** mounted at `http://localhost:3000/api-docs`.
- **PDF Report Engine:** **PDFKit** generating vector-rendered binary PDF Daily and Monthly business reports.
- **CSV Streamer:** RFC 4180 compliant CSV exports for sales auditing and inventory replenishment.

---

## 3. System Architecture

```mermaid
graph TD
    Client["React 18 SPA (Browser)<br/>Components: Dashboard, POS, Inventory, Reports"]
    API["Express.js REST API Server<br/>(Port 3000)"]
    Auth["JWT & bcryptjs Security<br/>Role-Based Access Control"]
    DB[("SQLite 3 Relational Database<br/>WAL Mode & Foreign Keys")]
    Reports["PDFKit & CSV Engine<br/>Daily & Monthly Reports"]
    Swagger["OpenAPI / Swagger UI<br/>/api-docs"]

    Client -->|HTTP / JSON with JWT Cookie| API
    API --> Auth
    API --> DB
    API --> Reports
    API --> Swagger
```

---

## 4. Default System Credentials

| Role | Name | Email | Password | Permissions |
| :--- | :--- | :--- | :--- | :--- |
| **Administrator** | Admin User | `admin@compstock.lk` | `admin123` | Full access: Inventory CRUD, Cost Prices, Reports, Users RBAC, Settings, Backups. |
| **Sales Staff** | Sales Staff | `staff@compstock.lk` | `staff123` | Operational access: POS checkout, Customer creation, Invoice viewing, Returns. |

> **Note:** New users can also register themselves directly using the **Register** tab on the login screen. Self-registered accounts automatically receive the **Sales Staff (Normal User)** role.

---

## 5. Quick Start & Installation

### Step 1: Install Dependencies
Open PowerShell or Command Prompt in the project folder:
```powershell
npm.cmd install
```

### Step 2: Build the React Application Bundle
```powershell
npm.cmd run build
```
*(The React bundle is compiled in ~80ms using `esbuild` into `public/dist/bundle.js`).*

### Step 3: Run the Automated Verification Tests
```powershell
npm.cmd test
```
*(Executes all 47 automated integration tests covering Authentication, RBAC, CRUD, Formulas, Returns, Swagger, and PDF generation).*

### Step 4: Start the Server
```powershell
npm.cmd start
```

### Step 5: Access the System
- **Main React Web Application:** [http://localhost:3000](http://localhost:3000)
- **Interactive Swagger REST API Docs:** [http://localhost:3000/api-docs](http://localhost:3000/api-docs)

---

## 6. Official University Requirements Compliance Checklist

| Mandatory Requirement | Status | Implementation Details |
| :--- | :---: | :--- |
| **SPA Architecture (React.js)** | **PASS** | Complete React 18 SPA (`src/App.jsx`, `src/components/*`) with state management, modular components, and dark/light theming. |
| **RESTful API Backend** | **PASS** | Express.js backend providing standard GET, POST, PUT, DELETE routes with JSON responses. |
| **Relational Database (RDBMS)** | **PASS** | SQLite 3 with primary keys, foreign keys (`PRAGMA foreign_keys = ON;`), WAL mode, and 137 seeded parts. |
| **User Registration & Login** | **PASS** | `POST /api/auth/register` and `POST /api/auth/login` with bcrypt hashing and validation. |
| **User Roles (Admin & Normal User)** | **PASS** | Role-Based Access Control (`admin` vs `sales`) enforced at API middleware and UI navigation levels. |
| **CRUD Operations** | **PASS** | Full Create, Read, Update, Delete for Products, Customers, Users, Sales, and Returns. |
| **Compulsory Daily Report** | **PASS** | Date filtering, real revenue calculation, CSV download, and binary PDF export via PDFKit. |
| **Compulsory Monthly Report** | **PASS** | Month filtering, monthly gross revenue, top selling product ranking, and PDF download. |
| **SQL Injection Prevention** | **PASS** | Prepared statements / parameterized SQL queries on 100% of database interactions. |
| **Centralized Logging** | **PASS** | Structured logger writing `[INFO]`, `[WARN]`, `[ERROR]` with timestamps to console and `logs/app.log`. |
| **OpenAPI / Swagger Documentation** | **PASS** | Interactive Swagger documentation available at `/api-docs`. |
| **Git Version Control** | **PASS** | Git repository initialized with meaningful commit history and `.gitignore`. |

---

## 7. Mathematical Formulas & Business Logic

1. **POS Financial Calculation (Strictly No Tax/VAT):**
   $$\text{Final Total} = \text{Subtotal} - \text{Discount Amount}$$
   $$\text{Change Returned} = \text{Amount Tendered} - \text{Final Total}$$

2. **Gross Profit Margin Formula:**
   $$\text{Gross Profit} = \sum (\text{Selling Price} - \text{Unit Cost}) \times \text{Quantity}$$
   $$\text{Gross Margin \%} = \left(\frac{\text{Gross Profit}}{\text{Total Revenue}}\right) \times 100$$

3. **Stock Restoration on Return:**
   $$\text{New Stock Quantity} = \text{Current Stock Quantity} + \text{Returned Quantity}$$

---

## 8. 14-Minute Viva Demonstration Guide

1. **Presentation (6 Mins):**
   - Explain problem: Small electronic component shops face stock inaccuracies, complex part numbers (SKUs), and pricing errors.
   - Explain solution: CompStock React SPA with SQLite WAL database and Express REST API.
2. **Live System Demonstration (10 Mins):**
   - **Login & Roles:** Log in as `staff@compstock.lk` -> Show POS access, demonstrate that Admin settings and User management are restricted. Log in as `admin@compstock.lk` -> Show full administrative controls.
   - **Registration:** Show Register tab -> Create a new user -> Confirm account creation and automatic role assignment.
   - **Inventory CRUD:** Search component "ESP32" -> Show instant barcode lookup -> Add new product -> Adjust stock.
   - **POS Checkout:** Add items to cart -> Edit quantity with `+` / `-` and direct typing -> Apply 10% discount -> Verify $\text{Subtotal} - \text{Discount} = \text{Total}$ formula -> Process Cash tender -> Generate invoice receipt.
   - **Sales Returns:** Go to Invoices -> Click Return Items -> Return 1 unit -> Verify stock is automatically restored in Inventory!
   - **Reports & Downloads:** Open Reports -> Select Daily Report -> Click **Download Official PDF** -> Show the PDF generated by PDFKit.
   - **API Docs:** Open `http://localhost:3000/api-docs` -> Show Swagger endpoints.
3. **Real-Time Code Modification (4 Mins):**
   - If asked to modify a discount limit, change a color token, or add a table column:
     - Color tokens: Edit `public/css/style.css` (`--copper` or `--table-row-hover`).
     - React Components: Edit the corresponding `.jsx` file in `src/components/` and run `npm run build` (builds in under 100 milliseconds).
