const swaggerJsdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'CompStock REST API Documentation',
      version: '1.0.0',
      description: 'Official REST API specification for CompStock - Small Shop Electronic Components Inventory and Sales POS System (IA 3208 Evaluation).',
      contact: {
        name: 'CompStock Engineering Team',
        email: 'info@compstock.lk'
      }
    },
    servers: [
      {
        url: 'http://localhost:3000',
        description: 'Local Development Server'
      }
    ],
    components: {
      securitySchemes: {
        cookieAuth: {
          type: 'apiKey',
          in: 'cookie',
          name: 'token',
          description: 'JWT Authentication cookie'
        },
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'Authorization header: Bearer <token>'
        }
      },
      schemas: {
        User: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            name: { type: 'string', example: 'Admin User' },
            email: { type: 'string', example: 'admin@compstock.lk' },
            role: { type: 'string', enum: ['admin', 'sales'], example: 'admin' },
            status: { type: 'string', enum: ['active', 'inactive'], example: 'active' },
            created_at: { type: 'string', format: 'date-time' }
          }
        },
        Product: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            name: { type: 'string', example: 'Arduino Uno R3' },
            sku: { type: 'string', example: 'MCU-UNO-R3' },
            barcode: { type: 'string', example: '890101500001' },
            category: { type: 'string', example: 'Microcontrollers' },
            unit_price: { type: 'number', example: 1850 },
            unit_cost: { type: 'number', example: 1250 },
            stock_quantity: { type: 'integer', example: 25 },
            min_stock_level: { type: 'integer', example: 5 },
            status: { type: 'string', example: 'active' }
          }
        },
        Customer: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            name: { type: 'string', example: 'Isuka Ranhiruu' },
            phone: { type: 'string', example: '0771234567' },
            email: { type: 'string', example: 'isuka@example.com' },
            company: { type: 'string', example: 'RoboTech Lanka' },
            status: { type: 'string', example: 'active' }
          }
        },
        Sale: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            invoice_number: { type: 'string', example: 'S-1001' },
            customer_id: { type: 'integer', example: 1 },
            customer_name: { type: 'string', example: 'Isuka Ranhiruu' },
            subtotal: { type: 'number', example: 3700 },
            discount: { type: 'number', example: 370 },
            total: { type: 'number', example: 3330 },
            amount_paid: { type: 'number', example: 3500 },
            change_amount: { type: 'number', example: 170 },
            payment_method: { type: 'string', example: 'cash' },
            payment_status: { type: 'string', example: 'paid' },
            created_at: { type: 'string', format: 'date-time' }
          }
        },
        ErrorResponse: {
          type: 'object',
          properties: {
            error: { type: 'string', example: 'Validation error message' }
          }
        }
      }
    },
    paths: {
      '/api/auth/register': {
        post: {
          tags: ['Authentication'],
          summary: 'Register a new user account (Normal User / Sales Staff)',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['name', 'email', 'password'],
                  properties: {
                    name: { type: 'string', example: 'Nuwan Perera' },
                    email: { type: 'string', example: 'nuwan@compstock.lk' },
                    password: { type: 'string', example: 'Secure@123' }
                  }
                }
              }
            }
          },
          responses: {
            201: {
              description: 'User registered successfully',
              content: { 'application/json': { schema: { $ref: '#/components/schemas/User' } } }
            },
            400: { description: 'Validation error or duplicate email' }
          }
        }
      },
      '/api/auth/login': {
        post: {
          tags: ['Authentication'],
          summary: 'Authenticate user and issue JWT token',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['password'],
                  properties: {
                    email: { type: 'string', example: 'admin@compstock.lk' },
                    password: { type: 'string', example: 'Admin@12345' }
                  }
                }
              }
            }
          },
          responses: {
            200: { description: 'Authenticated successfully with JWT cookie' },
            401: { description: 'Invalid username/email or password' }
          }
        }
      },
      '/api/auth/logout': {
        post: {
          tags: ['Authentication'],
          summary: 'Log out current session and invalidate cookie',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          responses: {
            200: { description: 'Logged out successfully' }
          }
        }
      },
      '/api/auth/me': {
        get: {
          tags: ['Authentication'],
          summary: 'Get currently authenticated user identity',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          responses: {
            200: { description: 'Current user profile' },
            401: { description: 'Not authenticated' }
          }
        }
      },
      '/api/products': {
        get: {
          tags: ['Products / Inventory'],
          summary: 'Get product catalog with filtering and search',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          parameters: [
            { in: 'query', name: 'search', schema: { type: 'string' } },
            { in: 'query', name: 'category', schema: { type: 'string' } },
            { in: 'query', name: 'status', schema: { type: 'string' } }
          ],
          responses: {
            200: { description: 'List of products' }
          }
        },
        post: {
          tags: ['Products / Inventory'],
          summary: 'Create a new product (Admin Only)',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['name', 'sku', 'unit_price', 'stock_quantity'],
                  properties: {
                    name: { type: 'string' },
                    sku: { type: 'string' },
                    barcode: { type: 'string' },
                    category: { type: 'string' },
                    unit_price: { type: 'number' },
                    unit_cost: { type: 'number' },
                    stock_quantity: { type: 'integer' },
                    min_stock_level: { type: 'integer' }
                  }
                }
              }
            }
          },
          responses: {
            201: { description: 'Product created' },
            403: { description: 'Forbidden - Admin only' }
          }
        }
      },
      '/api/products/{id}': {
        put: {
          tags: ['Products / Inventory'],
          summary: 'Update existing product (Admin Only)',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          parameters: [{ in: 'path', name: 'id', required: true, schema: { type: 'integer' } }],
          responses: { 200: { description: 'Product updated' } }
        },
        delete: {
          tags: ['Products / Inventory'],
          summary: 'Delete or deactivate product (Admin Only)',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          parameters: [{ in: 'path', name: 'id', required: true, schema: { type: 'integer' } }],
          responses: { 200: { description: 'Product deleted' } }
        }
      },
      '/api/customers': {
        get: {
          tags: ['Customers'],
          summary: 'Get all customers',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          responses: { 200: { description: 'List of customers' } }
        },
        post: {
          tags: ['Customers'],
          summary: 'Create a new customer',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['name'],
                  properties: {
                    name: { type: 'string' },
                    phone: { type: 'string' },
                    email: { type: 'string' },
                    company: { type: 'string' },
                    address: { type: 'string' }
                  }
                }
              }
            }
          },
          responses: { 201: { description: 'Customer created' } }
        }
      },
      '/api/customers/{id}': {
        put: {
          tags: ['Customers'],
          summary: 'Update customer details',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          parameters: [{ in: 'path', name: 'id', required: true, schema: { type: 'integer' } }],
          responses: { 200: { description: 'Customer updated' } }
        },
        delete: {
          tags: ['Customers'],
          summary: 'Delete customer',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          parameters: [{ in: 'path', name: 'id', required: true, schema: { type: 'integer' } }],
          responses: { 200: { description: 'Customer deleted or deactivated' } }
        }
      },
      '/api/sales': {
        get: {
          tags: ['Sales / POS'],
          summary: 'List sales transactions',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          responses: { 200: { description: 'List of sales' } }
        },
        post: {
          tags: ['Sales / POS'],
          summary: 'Process POS checkout transaction (Authoritative stock deduction & financial formula)',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['items'],
                  properties: {
                    customer_id: { type: 'integer' },
                    customer_name: { type: 'string' },
                    items: {
                      type: 'array',
                      items: {
                        type: 'object',
                        required: ['product_id', 'quantity', 'unit_price'],
                        properties: {
                          product_id: { type: 'integer' },
                          quantity: { type: 'integer' },
                          unit_price: { type: 'number' }
                        }
                      }
                    },
                    discount_type: { type: 'string', enum: ['fixed', 'percentage'] },
                    discount_rate: { type: 'number' },
                    amount_paid: { type: 'number' },
                    payment_method: { type: 'string', enum: ['cash', 'card', 'transfer'] }
                  }
                }
              }
            }
          },
          responses: {
            201: { description: 'Sale processed successfully' },
            400: { description: 'Insufficient stock or invalid input' }
          }
        }
      },
      '/api/returns': {
        post: {
          tags: ['Sales Returns'],
          summary: 'Process product return with inventory quantity restoration',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          responses: { 201: { description: 'Return processed' } }
        }
      },
      '/api/reports/daily': {
        get: {
          tags: ['Reporting'],
          summary: 'Compulsory Daily Sales Report with date filtering and revenue KPIs',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          parameters: [{ in: 'query', name: 'date', schema: { type: 'string', example: '2026-11-18' } }],
          responses: { 200: { description: 'Daily report summary and transaction lines' } }
        }
      },
      '/api/reports/monthly': {
        get: {
          tags: ['Reporting'],
          summary: 'Compulsory Monthly Sales Report with revenue trends and top products',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          parameters: [{ in: 'query', name: 'month', schema: { type: 'string', example: '2026-11' } }],
          responses: { 200: { description: 'Monthly report metrics, trends and ranking' } }
        }
      },
      '/api/export/csv': {
        get: {
          tags: ['Exports & Downloads'],
          summary: 'Download reports as clean CSV file',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          parameters: [
            { in: 'query', name: 'type', required: true, schema: { type: 'string', enum: ['daily', 'monthly', 'forecasting', 'profit'] } },
            { in: 'query', name: 'date', schema: { type: 'string' } },
            { in: 'query', name: 'month', schema: { type: 'string' } }
          ],
          responses: {
            200: {
              description: 'CSV file download',
              content: { 'text/csv': {} }
            }
          }
        }
      },
      '/api/export/pdf': {
        get: {
          tags: ['Exports & Downloads'],
          summary: 'Download official PDF Business Report (Daily / Monthly)',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          parameters: [
            { in: 'query', name: 'type', required: true, schema: { type: 'string', enum: ['daily', 'monthly'] } },
            { in: 'query', name: 'date', schema: { type: 'string' } },
            { in: 'query', name: 'month', schema: { type: 'string' } }
          ],
          responses: {
            200: {
              description: 'Binary PDF file download',
              content: { 'application/pdf': {} }
            }
          }
        }
      },
      '/api/users': {
        get: {
          tags: ['User Management'],
          summary: 'List application users (Admin Only)',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          responses: { 200: { description: 'List of users' } }
        },
        post: {
          tags: ['User Management'],
          summary: 'Add/invite user with specific role (Admin Only)',
          security: [{ cookieAuth: [] }, { bearerAuth: [] }],
          responses: { 201: { description: 'User created' } }
        }
      }
    }
  },
  apis: []
};

const swaggerSpec = swaggerJsdoc(options);

module.exports = swaggerSpec;
