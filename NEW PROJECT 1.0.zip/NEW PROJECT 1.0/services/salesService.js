const { query, queryOne, run, transaction } = require('../database/db');
const { logAudit } = require('./auditService');

/**
 * Generate sequential invoice number finding absolute maximum numeric ID
 */
function getNextInvoiceNumber() {
  const prefixRow = queryOne("SELECT value FROM settings WHERE key = 'invoice_prefix'");
  const prefix = prefixRow ? prefixRow.value : 'S-';
  const allSales = query("SELECT invoice_number FROM sales WHERE invoice_number LIKE ?", [`${prefix}%`]);
  let maxNum = 1000;
  for (const s of allSales) {
    const regex = new RegExp(`^${prefix}(\\d+)`);
    const match = s.invoice_number.match(regex);
    if (match) {
      const n = parseInt(match[1], 10);
      if (n > maxNum) maxNum = n;
    }
  }
  return `${prefix}${maxNum + 1}`;
}

/**
 * Generate sequential return number
 */
function getNextReturnNumber() {
  const allReturns = query("SELECT return_number FROM returns WHERE return_number LIKE 'RET-%'");
  let maxNum = 1000;
  for (const r of allReturns) {
    const match = r.return_number.match(/^RET-(\d+)/);
    if (match) {
      const n = parseInt(match[1], 10);
      if (n > maxNum) maxNum = n;
    }
  }
  return `RET-${maxNum + 1}`;
}

/**
 * Authoritatively process and execute a sale inside an atomic database transaction
 */
function processSale({
  customerId = null,
  customerName = 'Walk-in',
  paymentMethod = 'cash',
  paymentStatus = 'paid',
  discountType = 'fixed',
  discountRate = 0,
  discountAmount = 0,
  amountPaid = 0,
  items,
  user
}) {
  if (!items || !Array.isArray(items) || items.length === 0) {
    throw new Error('Cart must contain at least one item');
  }

  // Consolidate duplicate requested items by product_id
  const consolidated = [];
  for (const it of items) {
    const prodId = parseInt(it.product_id);
    const qty = parseInt(it.quantity);
    if (!prodId || isNaN(qty) || qty <= 0) {
      throw new Error('Invalid product or quantity specified');
    }
    const existing = consolidated.find(r => r.product_id === prodId);
    if (existing) {
      existing.quantity += qty;
    } else {
      consolidated.push({ product_id: prodId, quantity: qty });
    }
  }

  let createdSaleId = null;
  let invoiceNumber = '';

  transaction(() => {
    invoiceNumber = getNextInvoiceNumber();
    let subtotal = 0;
    let totalCost = 0;
    const verifiedItems = [];

    // Verify stock and fetch authoritative prices
    for (const item of consolidated) {
      const product = queryOne('SELECT * FROM products WHERE id = ?', [item.product_id]);
      if (!product) {
        throw new Error(`Product with ID ${item.product_id} not found`);
      }
      if (product.status !== 'active') {
        throw new Error(`Product "${product.name}" (${product.sku}) is inactive and cannot be sold`);
      }
      if (product.stock_quantity < item.quantity) {
        throw new Error(`Insufficient stock for "${product.name}". Available: ${product.stock_quantity}, Requested: ${item.quantity}`);
      }

      const lineTotal = product.selling_price * item.quantity;
      const lineCost = (product.cost_price || 0) * item.quantity;
      subtotal += lineTotal;
      totalCost += lineCost;

      verifiedItems.push({
        product,
        quantity: item.quantity,
        unit_price: product.selling_price,
        unit_cost: product.cost_price || 0,
        line_total: lineTotal
      });
    }

    // Authoritatively calculate discount
    let calcDiscount = 0;
    const dRate = Math.max(0, parseFloat(discountRate) || 0);
    const dAmount = Math.max(0, parseFloat(discountAmount) || 0);

    if (discountType === 'percentage') {
      calcDiscount = Math.min(subtotal, (subtotal * dRate) / 100);
    } else {
      calcDiscount = Math.min(subtotal, dAmount);
    }

    // Formula: Subtotal - Discount = Final Total (No VAT / Sales Tax)
    const finalTotal = Math.max(0, subtotal - calcDiscount);

    // Calculate payment balance / change
    const paid = parseFloat(amountPaid) > 0 ? parseFloat(amountPaid) : finalTotal;
    const changeAmount = Math.max(0, paid - finalTotal);

    // Look up customer name if ID provided
    let finalCustName = customerName ? customerName.trim() : 'Walk-in';
    let validCustId = null;
    if (customerId) {
      const cust = queryOne('SELECT id, name FROM customers WHERE id = ?', [customerId]);
      if (cust) {
        validCustId = cust.id;
        finalCustName = cust.name;
      }
    }

    // 1. Insert master sale record
    const saleResult = run(
      `INSERT INTO sales 
       (invoice_number, customer_id, customer_name, subtotal, discount, discount_type, discount_rate, tax, total, amount_paid, change_amount, payment_status, payment_method, return_status, created_by, created_at) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      [
        invoiceNumber,
        validCustId,
        finalCustName,
        subtotal,
        calcDiscount,
        discountType,
        discountType === 'percentage' ? dRate : 0,
        0,
        finalTotal,
        paid,
        changeAmount,
        paymentStatus,
        paymentMethod,
        'none',
        user.id
      ]
    );
    createdSaleId = saleResult.lastInsertRowid;

    // 2. Insert items, decrement stock, and record stock movements
    for (const it of verifiedItems) {
      run(
        `INSERT INTO sale_items 
         (sale_id, product_id, product_name, sku, quantity, unit_price, unit_cost, line_total, returned_quantity) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)`,
        [
          createdSaleId,
          it.product.id,
          it.product.name,
          it.product.sku,
          it.quantity,
          it.unit_price,
          it.unit_cost,
          it.line_total
        ]
      );

      const newStock = it.product.stock_quantity - it.quantity;
      run(
        'UPDATE products SET stock_quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [newStock, it.product.id]
      );

      run(
        `INSERT INTO stock_movements 
         (product_id, previous_quantity, quantity_change, new_quantity, reason, reference_id, user_id, created_at) 
         VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
        [
          it.product.id,
          it.product.stock_quantity,
          -it.quantity,
          newStock,
          'sale',
          invoiceNumber,
          user.id
        ]
      );
    }

    logAudit({
      userId: user.id,
      userName: user.name,
      action: 'CREATE_SALE',
      description: `Completed sale #${invoiceNumber} for ${finalCustName} — Total: Rs ${finalTotal.toFixed(2)} (${verifiedItems.length} items)`,
      relatedId: invoiceNumber
    });
  });

  const fullSale = queryOne(
    `SELECT s.*, u.name as staff_name, c.phone as customer_phone, c.email as customer_email 
     FROM sales s 
     LEFT JOIN users u ON s.created_by = u.id 
     LEFT JOIN customers c ON s.customer_id = c.id 
     WHERE s.id = ?`,
    [createdSaleId]
  );
  const itemsList = query('SELECT * FROM sale_items WHERE sale_id = ? ORDER BY id ASC', [createdSaleId]);

  return {
    ...fullSale,
    items: itemsList
  };
}

/**
 * Process a customer sales return / refund inside an atomic transaction
 */
function processReturn({ invoiceNumber, items, reason = 'Customer Return', user }) {
  if (!items || !Array.isArray(items) || items.length === 0) {
    throw new Error('Return must specify at least one item');
  }

  const sale = queryOne('SELECT * FROM sales WHERE invoice_number = ?', [invoiceNumber]);
  if (!sale) {
    throw new Error(`Invoice #${invoiceNumber} not found`);
  }

  let createdReturnId = null;
  let returnNumber = '';
  let totalRefund = 0;

  transaction(() => {
    returnNumber = getNextReturnNumber();
    const verifiedReturnItems = [];

    for (const it of items) {
      const saleItemId = parseInt(it.sale_item_id);
      const retQty = parseInt(it.quantity);

      if (!saleItemId || isNaN(retQty) || retQty <= 0) {
        throw new Error('Invalid item or return quantity');
      }

      const saleItem = queryOne('SELECT * FROM sale_items WHERE id = ? AND sale_id = ?', [saleItemId, sale.id]);
      if (!saleItem) {
        throw new Error(`Sale line item ID ${saleItemId} does not belong to invoice #${invoiceNumber}`);
      }

      const alreadyReturned = saleItem.returned_quantity || 0;
      const eligibleQty = saleItem.quantity - alreadyReturned;

      if (retQty > eligibleQty) {
        throw new Error(`Cannot return ${retQty} units of "${saleItem.product_name}". Only ${eligibleQty} units eligible for return.`);
      }

      const refundAmount = saleItem.unit_price * retQty;
      totalRefund += refundAmount;

      verifiedReturnItems.push({
        saleItem,
        quantity: retQty,
        unit_price: saleItem.unit_price,
        line_refund: refundAmount
      });
    }

    // 1. Insert master return record
    const retRes = run(
      `INSERT INTO returns (return_number, sale_id, invoice_number, total_refund, reason, created_by, created_at)
       VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      [returnNumber, sale.id, sale.invoice_number, totalRefund, reason.trim(), user.id]
    );
    createdReturnId = retRes.lastInsertRowid;

    // 2. Insert return items, restore stock, and record stock movements
    for (const retIt of verifiedReturnItems) {
      run(
        `INSERT INTO return_items (return_id, sale_item_id, product_id, product_name, sku, quantity, unit_price, line_refund)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          createdReturnId,
          retIt.saleItem.id,
          retIt.saleItem.product_id,
          retIt.saleItem.product_name,
          retIt.saleItem.sku,
          retIt.quantity,
          retIt.unit_price,
          retIt.line_refund
        ]
      );

      // Update returned_quantity on original sale item
      run(
        'UPDATE sale_items SET returned_quantity = returned_quantity + ? WHERE id = ?',
        [retIt.quantity, retIt.saleItem.id]
      );

      // Restore product stock
      const prod = queryOne('SELECT stock_quantity FROM products WHERE id = ?', [retIt.saleItem.product_id]);
      const currentStock = prod ? prod.stock_quantity : 0;
      const newStock = currentStock + retIt.quantity;

      run(
        'UPDATE products SET stock_quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [newStock, retIt.saleItem.product_id]
      );

      // Stock movement with customer_return reason
      run(
        `INSERT INTO stock_movements 
         (product_id, previous_quantity, quantity_change, new_quantity, reason, reference_id, user_id, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
        [
          retIt.saleItem.product_id,
          currentStock,
          retIt.quantity,
          newStock,
          'customer_return',
          returnNumber,
          user.id
        ]
      );
    }

    // 3. Determine if sale is now fully or partially returned
    const allSaleItems = query('SELECT quantity, returned_quantity FROM sale_items WHERE sale_id = ?', [sale.id]);
    const totalOriginal = allSaleItems.reduce((acc, i) => acc + i.quantity, 0);
    const totalReturned = allSaleItems.reduce((acc, i) => acc + (i.returned_quantity || 0), 0);
    const newStatus = totalReturned >= totalOriginal ? 'full' : 'partial';

    run('UPDATE sales SET return_status = ? WHERE id = ?', [newStatus, sale.id]);

    logAudit({
      userId: user.id,
      userName: user.name,
      action: 'SALE_RETURN',
      description: `Processed return #${returnNumber} for invoice #${invoiceNumber} — Total Refund: Rs ${totalRefund.toFixed(2)}. Reason: ${reason}`,
      relatedId: returnNumber
    });
  });

  const fullReturn = queryOne(
    `SELECT r.*, u.name as staff_name 
     FROM returns r 
     LEFT JOIN users u ON r.created_by = u.id 
     WHERE r.id = ?`,
    [createdReturnId]
  );
  const returnItemsList = query('SELECT * FROM return_items WHERE return_id = ?', [createdReturnId]);

  return {
    ...fullReturn,
    items: returnItemsList
  };
}

module.exports = {
  getNextInvoiceNumber,
  getNextReturnNumber,
  processSale,
  processReturn
};
