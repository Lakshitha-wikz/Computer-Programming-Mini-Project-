const { query, queryOne } = require('../database/db');
const { getValuation } = require('./inventoryService');

/**
 * Filter SQL sales by period or custom date range
 */
function buildDateCondition(period, startDate, endDate, alias = 's') {
  if (startDate && endDate) {
    return {
      sql: ` AND date(${alias}.created_at, 'localtime') >= date(?) AND date(${alias}.created_at, 'localtime') <= date(?)`,
      params: [startDate, endDate]
    };
  }

  switch (period) {
    case 'today':
      return {
        sql: ` AND date(${alias}.created_at, 'localtime') = date('now', 'localtime')`,
        params: []
      };
    case 'yesterday':
      return {
        sql: ` AND date(${alias}.created_at, 'localtime') = date('now', 'localtime', '-1 day')`,
        params: []
      };
    case 'week':
      return {
        sql: ` AND date(${alias}.created_at, 'localtime') >= date('now', 'localtime', '-7 days')`,
        params: []
      };
    case 'month':
      return {
        sql: ` AND strftime('%Y-%m', ${alias}.created_at, 'localtime') = strftime('%Y-%m', 'now', 'localtime')`,
        params: []
      };
    case 'year':
      return {
        sql: ` AND strftime('%Y', ${alias}.created_at, 'localtime') = strftime('%Y', 'now', 'localtime')`,
        params: []
      };
    default:
      return {
        sql: ` AND date(${alias}.created_at, 'localtime') >= date('now', 'localtime', '-30 days')`,
        params: []
      };
  }
}

/**
 * Compile Dashboard summary statistics
 */
function getDashboardKPIs() {
  const totalProducts = queryOne("SELECT COUNT(*) as c FROM products WHERE status = 'active'").c;

  // 1. Sales summary (single row query on sales - no cartesian join duplication)
  const todaySalesData = queryOne(`
    SELECT 
      COALESCE(SUM(total), 0) as gross_revenue,
      COUNT(id) as tx_count,
      COALESCE(SUM(discount), 0) as total_discount
    FROM sales
    WHERE date(created_at, 'localtime') = date('now', 'localtime')
  `);

  // 2. Refunds today
  const todayRefundsData = queryOne(`
    SELECT COALESCE(SUM(total_refund), 0) as total_refunds
    FROM returns
    WHERE date(created_at, 'localtime') = date('now', 'localtime')
  `);

  // 3. Cost & net units sold today
  const todayItemsData = queryOne(`
    SELECT 
      COALESCE(SUM(si.quantity - si.returned_quantity), 0) as units_sold,
      COALESCE(SUM(si.unit_cost * (si.quantity - si.returned_quantity)), 0) as cost
    FROM sale_items si
    JOIN sales s ON si.sale_id = s.id
    WHERE date(s.created_at, 'localtime') = date('now', 'localtime')
  `);

  const grossRevenue = todaySalesData ? todaySalesData.gross_revenue : 0;
  const refunds = todayRefundsData ? todayRefundsData.total_refunds : 0;
  const todayRevenue = Math.max(0, grossRevenue - refunds);
  const todayCost = todayItemsData ? todayItemsData.cost : 0;
  const todayProfit = Math.max(0, todayRevenue - todayCost);
  const profitMargin = todayRevenue > 0 ? ((todayProfit / todayRevenue) * 100) : 0;

  // Low Stock & Out of Stock counts
  const lowStockCount = queryOne(
    "SELECT COUNT(*) as c FROM products WHERE status = 'active' AND stock_quantity > 0 AND stock_quantity <= low_stock_threshold"
  ).c;

  const outOfStockCount = queryOne(
    "SELECT COUNT(*) as c FROM products WHERE status = 'active' AND stock_quantity = 0"
  ).c;

  // Valuation
  const valuation = getValuation();

  // Recent 6 sales
  const recentSales = query(`
    SELECT s.id, s.invoice_number, s.customer_name, s.total, s.payment_status, s.payment_method, s.created_at,
      (SELECT GROUP_CONCAT(product_name || ' ×' || quantity, ', ') FROM sale_items WHERE sale_id = s.id) as items_summary
    FROM sales s
    ORDER BY s.id DESC
    LIMIT 6
  `);

  // Low stock items
  const lowStockItems = query(`
    SELECT id, name, sku, stock_quantity, low_stock_threshold 
    FROM products 
    WHERE status = 'active' AND stock_quantity <= low_stock_threshold 
    ORDER BY stock_quantity ASC 
    LIMIT 6
  `);

  return {
    total_products: totalProducts,
    today_sales: Math.round(todayRevenue * 100) / 100,
    today_cost: Math.round(todayCost * 100) / 100,
    today_profit: Math.round(todayProfit * 100) / 100,
    profit_margin: Math.round(profitMargin * 10) / 10,
    transactions_today: todaySalesData ? todaySalesData.tx_count : 0,
    low_stock_count: lowStockCount,
    out_of_stock_count: outOfStockCount,
    inventory_valuation: valuation,
    recent_sales: recentSales,
    low_stock_items: lowStockItems
  };
}

/**
 * Sales and Profit summary report for selected period
 */
function getSalesReport({ period = 'today', startDate, endDate }) {
  const dateCondSales = buildDateCondition(period, startDate, endDate, 's');
  const dateCondReturns = buildDateCondition(period, startDate, endDate, 'r');

  // 1. Pure sales totals without join multiplier
  const salesSummary = queryOne(`
    SELECT 
      COALESCE(SUM(s.total), 0) as gross_revenue,
      COUNT(s.id) as transaction_count,
      COALESCE(SUM(s.discount), 0) as total_discount
    FROM sales s
    WHERE 1=1 ${dateCondSales.sql}
  `, dateCondSales.params);

  // 2. Refunds in this period
  const refundsSummary = queryOne(`
    SELECT COALESCE(SUM(r.total_refund), 0) as total_refunds
    FROM returns r
    WHERE 1=1 ${dateCondReturns.sql}
  `, dateCondReturns.params);

  // 3. Cost and net units sold from sale items in this period
  const itemsSummary = queryOne(`
    SELECT 
      COALESCE(SUM(si.quantity - si.returned_quantity), 0) as units_sold,
      COALESCE(SUM(si.unit_cost * (si.quantity - si.returned_quantity)), 0) as total_cost
    FROM sale_items si
    JOIN sales s ON si.sale_id = s.id
    WHERE 1=1 ${dateCondSales.sql}
  `, dateCondSales.params);

  const grossRevenue = salesSummary ? salesSummary.gross_revenue : 0;
  const refunds = refundsSummary ? refundsSummary.total_refunds : 0;
  const revenue = Math.max(0, grossRevenue - refunds);
  const cost = itemsSummary ? itemsSummary.total_cost : 0;
  const profit = Math.max(0, revenue - cost);
  const margin = revenue > 0 ? (profit / revenue) * 100 : 0;
  const txCount = salesSummary ? salesSummary.transaction_count : 0;
  const atv = txCount > 0 ? revenue / txCount : 0;

  // Itemized transactions
  const sales = query(`
    SELECT s.id, s.invoice_number, s.customer_name, s.total, s.subtotal, s.discount, s.payment_status, s.payment_method, s.created_at,
      time(s.created_at, 'localtime') as formatted_time,
      date(s.created_at, 'localtime') as formatted_date,
      (SELECT GROUP_CONCAT(product_name || ' ×' || quantity, ', ') FROM sale_items WHERE sale_id = s.id) as items_summary,
      (SELECT COALESCE(SUM(unit_cost * (quantity - returned_quantity)), 0) FROM sale_items WHERE sale_id = s.id) as order_cost,
      (SELECT COALESCE(SUM(total_refund), 0) FROM returns WHERE sale_id = s.id) as order_refund
    FROM sales s
    WHERE 1=1 ${dateCondSales.sql}
    ORDER BY s.id DESC
  `, dateCondSales.params);

  // Computed per-sale net profit
  const salesWithProfit = sales.map(s => {
    const netOrderRevenue = Math.max(0, s.total - (s.order_refund || 0));
    const saleProfit = Math.max(0, netOrderRevenue - (s.order_cost || 0));
    return {
      ...s,
      net_revenue: netOrderRevenue,
      order_profit: Math.round(saleProfit * 100) / 100
    };
  });

  return {
    kpis: {
      revenue: Math.round(revenue * 100) / 100,
      cost: Math.round(cost * 100) / 100,
      profit: Math.round(profit * 100) / 100,
      margin: Math.round(margin * 10) / 10,
      transactions: txCount,
      units_sold: itemsSummary ? itemsSummary.units_sold : 0,
      average_transaction_value: Math.round(atv * 100) / 100,
      discount_given: salesSummary ? salesSummary.total_discount : 0,
      refunds_given: refunds
    },
    sales: salesWithProfit
  };
}

/**
 * Top selling products breakdown
 */
function getTopSellingProducts({ limit = 10, startDate, endDate }) {
  let dateSql = '';
  const params = [];
  if (startDate && endDate) {
    dateSql = " AND date(s.created_at, 'localtime') >= date(?) AND date(s.created_at, 'localtime') <= date(?)";
    params.push(startDate, endDate);
  } else {
    dateSql = " AND date(s.created_at, 'localtime') >= date('now', 'localtime', '-30 days')";
  }

  params.push(parseInt(limit) || 10);

  const rows = query(`
    SELECT 
      si.product_id,
      si.product_name,
      si.sku,
      p.category,
      SUM(si.quantity - si.returned_quantity) as units_sold,
      SUM(si.unit_price * (si.quantity - si.returned_quantity)) as revenue,
      SUM(si.unit_cost * (si.quantity - si.returned_quantity)) as total_cost,
      SUM((si.unit_price - si.unit_cost) * (si.quantity - si.returned_quantity)) as profit
    FROM sale_items si
    JOIN sales s ON si.sale_id = s.id
    LEFT JOIN products p ON si.product_id = p.id
    WHERE 1=1 ${dateSql}
    GROUP BY si.product_id, si.product_name, si.sku
    HAVING units_sold > 0
    ORDER BY units_sold DESC
    LIMIT ?
  `, params);

  return rows.map(r => ({
    ...r,
    profit_margin: r.revenue > 0 ? Math.round(((r.profit / r.revenue) * 100) * 10) / 10 : 0
  }));
}

/**
 * Sales calendar data: returns revenue and count for each day of a given month
 */
function getSalesCalendarData({ year, month }) {
  const y = year || new Date().getFullYear();
  const m = month ? String(month).padStart(2, '0') : String(new Date().getMonth() + 1).padStart(2, '0');
  const targetYearMonth = `${y}-${m}`;

  const rows = query(`
    SELECT 
      date(s.created_at, 'localtime') as sale_date,
      strftime('%d', s.created_at, 'localtime') as day,
      COUNT(s.id) as transaction_count,
      COALESCE(SUM(s.total), 0) as total_revenue,
      COALESCE((
        SELECT SUM(si.quantity - si.returned_quantity)
        FROM sale_items si
        JOIN sales s2 ON si.sale_id = s2.id
        WHERE date(s2.created_at, 'localtime') = date(s.created_at, 'localtime')
      ), 0) as units_sold,
      COALESCE((
        SELECT SUM((si.unit_price - si.unit_cost) * (si.quantity - si.returned_quantity))
        FROM sale_items si
        JOIN sales s2 ON si.sale_id = s2.id
        WHERE date(s2.created_at, 'localtime') = date(s.created_at, 'localtime')
      ), 0) as total_profit
    FROM sales s
    WHERE strftime('%Y-%m', s.created_at, 'localtime') = ?
    GROUP BY date(s.created_at, 'localtime')
    ORDER BY sale_date ASC
  `, [targetYearMonth]);

  return {
    year: y,
    month: m,
    days: rows
  };
}

/**
 * Revenue trend over the last 14-30 days
 */
function getRevenueTrend() {
  const trend = query(`
    SELECT 
      strftime('%m-%d', s.created_at, 'localtime') as day_label,
      date(s.created_at, 'localtime') as full_date,
      COALESCE(SUM(s.total), 0) as daily_revenue,
      COALESCE((
        SELECT SUM((si.unit_price - si.unit_cost) * (si.quantity - si.returned_quantity))
        FROM sale_items si
        JOIN sales s2 ON si.sale_id = s2.id
        WHERE date(s2.created_at, 'localtime') = date(s.created_at, 'localtime')
      ), 0) as daily_profit,
      COUNT(s.id) as tx_count
    FROM sales s
    WHERE date(s.created_at, 'localtime') >= date('now', 'localtime', '-30 days')
    GROUP BY strftime('%m-%d', s.created_at, 'localtime')
    ORDER BY full_date ASC
  `);

  return trend;
}

module.exports = {
  getDashboardKPIs,
  getSalesReport,
  getTopSellingProducts,
  getSalesCalendarData,
  getRevenueTrend
};
