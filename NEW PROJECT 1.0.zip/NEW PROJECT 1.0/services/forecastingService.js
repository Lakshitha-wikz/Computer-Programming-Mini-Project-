const { query, queryOne } = require('../database/db');

/**
 * Compute stock forecast for all active products based on 30-day sales history
 */
function getStockForecasts() {
  const products = query("SELECT id, name, sku, category, stock_quantity, low_stock_threshold, cost_price, selling_price FROM products WHERE status = 'active' ORDER BY name ASC");

  const sales30d = query(`
    SELECT 
      si.product_id, 
      COALESCE(SUM(si.quantity), 0) as units_sold_30d
    FROM sale_items si
    JOIN sales s ON si.sale_id = s.id
    WHERE date(s.created_at, 'localtime') >= date('now', 'localtime', '-30 days')
    GROUP BY si.product_id
  `);

  const salesMap = new Map();
  for (const row of sales30d) {
    salesMap.set(row.product_id, row.units_sold_30d);
  }

  const forecasts = products.map(p => {
    const unitsSold = salesMap.get(p.id) || 0;
    const avgDailySales = Math.round((unitsSold / 30) * 10) / 10; // 1 decimal place

    let daysRemaining = null;
    let status = 'Healthy';
    let recommendedOrder = 0;

    if (p.stock_quantity === 0) {
      status = 'Critical';
      daysRemaining = 0;
      recommendedOrder = Math.max(p.low_stock_threshold * 2, Math.round(avgDailySales * 30) || 10);
    } else if (avgDailySales > 0) {
      daysRemaining = Math.round(p.stock_quantity / avgDailySales);
      if (daysRemaining <= 5 || p.stock_quantity <= p.low_stock_threshold) {
        status = 'Restock Soon';
        recommendedOrder = Math.max(p.low_stock_threshold * 2 - p.stock_quantity, Math.round(avgDailySales * 20));
      } else if (daysRemaining <= 14) {
        status = 'Monitor';
      } else {
        status = 'Healthy';
      }
    } else {
      if (p.stock_quantity <= p.low_stock_threshold) {
        status = 'Restock Soon';
        recommendedOrder = p.low_stock_threshold * 2 - p.stock_quantity;
      } else {
        status = 'Healthy';
      }
      daysRemaining = p.stock_quantity > 0 ? '> 60' : 0;
    }

    return {
      id: p.id,
      name: p.name,
      sku: p.sku,
      category: p.category,
      current_stock: p.stock_quantity,
      threshold: p.low_stock_threshold,
      units_sold_30d: unitsSold,
      avg_daily_sales: avgDailySales,
      days_remaining: daysRemaining,
      status, // 'Healthy', 'Monitor', 'Restock Soon', 'Critical'
      recommended_order: recommendedOrder,
      estimated_reorder_cost: recommendedOrder * (p.cost_price || 0)
    };
  });

  return forecasts;
}

/**
 * Filter down to just items requiring restocking attention
 */
function getReorderRecommendations() {
  const allForecasts = getStockForecasts();
  return allForecasts
    .filter(f => f.status === 'Critical' || f.status === 'Restock Soon')
    .sort((a, b) => {
      if (a.status === 'Critical' && b.status !== 'Critical') return -1;
      if (b.status === 'Critical' && a.status !== 'Critical') return 1;
      return a.current_stock - b.current_stock;
    });
}

module.exports = {
  getStockForecasts,
  getReorderRecommendations
};
