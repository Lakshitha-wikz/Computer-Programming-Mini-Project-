const { query } = require('../database/db');

/**
 * Compile live smart notifications from the database
 */
function getNotifications() {
  const notifications = [];

  // 1. Out of Stock Alerts
  const outOfStockProds = query(
    "SELECT id, name, sku, category FROM products WHERE status = 'active' AND stock_quantity = 0 ORDER BY updated_at DESC LIMIT 5"
  );
  for (const p of outOfStockProds) {
    notifications.push({
      id: `out-of-stock-${p.id}`,
      type: 'danger',
      title: 'Out of Stock Alert',
      message: `"${p.name}" (${p.sku}) is completely depleted (0 units available).`,
      timestamp: 'Immediate',
      category: 'inventory',
      linkScreen: 'inventory',
      productId: p.id
    });
  }

  // 2. Low Stock Alerts
  const lowStockProds = query(
    `SELECT id, name, sku, stock_quantity, low_stock_threshold 
     FROM products 
     WHERE status = 'active' AND stock_quantity > 0 AND stock_quantity <= low_stock_threshold 
     ORDER BY stock_quantity ASC LIMIT 6`
  );
  for (const p of lowStockProds) {
    notifications.push({
      id: `low-stock-${p.id}`,
      type: 'warning',
      title: 'Low Stock Warning',
      message: `"${p.name}" (${p.sku}) has only ${p.stock_quantity} left (Threshold: ${p.low_stock_threshold}).`,
      timestamp: 'Action Needed',
      category: 'inventory',
      linkScreen: 'inventory',
      productId: p.id
    });
  }

  // 3. Large Stock Adjustments (last 7 days, change >= 20)
  const largeMoves = query(
    `SELECT sm.id, sm.quantity_change, sm.reason, sm.created_at, p.name as product_name, p.sku 
     FROM stock_movements sm
     JOIN products p ON sm.product_id = p.id
     WHERE ABS(sm.quantity_change) >= 20 
     AND date(sm.created_at, 'localtime') >= date('now', 'localtime', '-7 days')
     ORDER BY sm.id DESC LIMIT 4`
  );
  for (const m of largeMoves) {
    notifications.push({
      id: `stock-move-${m.id}`,
      type: 'info',
      title: 'Large Stock Adjustment',
      message: `${m.quantity_change > 0 ? '+' : ''}${m.quantity_change} units for "${m.product_name}" (${m.reason}).`,
      timestamp: m.created_at,
      category: 'audit',
      linkScreen: 'reports'
    });
  }

  // 4. Recent Sales Activity
  const recentSales = query(
    `SELECT invoice_number, customer_name, total, created_at 
     FROM sales 
     ORDER BY id DESC LIMIT 3`
  );
  for (const s of recentSales) {
    notifications.push({
      id: `sale-${s.invoice_number}`,
      type: 'success',
      title: 'Recent Sale Confirmed',
      message: `Invoice #${s.invoice_number} generated for ${s.customer_name} (Rs ${s.total.toLocaleString()}).`,
      timestamp: s.created_at,
      category: 'sales',
      linkScreen: 'sales'
    });
  }

  // 5. System Activity from Audit Logs
  const recentLogs = query(
    `SELECT action, description, created_at 
     FROM audit_logs 
     WHERE action IN ('CREATE_USER', 'SALE_RETURN', 'BACKUP')
     ORDER BY id DESC LIMIT 2`
  );
  for (const l of recentLogs) {
    notifications.push({
      id: `audit-${Math.random()}`,
      type: 'activity',
      title: `System: ${l.action}`,
      message: l.description,
      timestamp: l.created_at,
      category: 'audit',
      linkScreen: 'audit'
    });
  }

  return notifications;
}

module.exports = { getNotifications };
