const { run } = require('../database/db');

/**
 * Log an event to the audit_logs table
 */
function logAudit({ userId = null, userName = 'System', action, description, relatedId = null, ipAddress = null }) {
  try {
    run(
      `INSERT INTO audit_logs (user_id, user_name, action, description, related_id, ip_address, created_at)
       VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      [userId, userName, action, description, relatedId ? String(relatedId) : null, ipAddress]
    );
  } catch (err) {
    console.error('Failed to log audit event:', err.message);
  }
}

module.exports = { logAudit };
