const { query, queryOne, run, transaction } = require('../database/db');
const { logAudit } = require('./auditService');

/**
 * Calculate full inventory valuation from actual SQL data
 */
function getValuation() {
  const stats = queryOne(`
    SELECT 
      COALESCE(SUM(cost_price * stock_quantity), 0) as total_cost_value,
      COALESCE(SUM(selling_price * stock_quantity), 0) as potential_sales_value,
      COALESCE(SUM((selling_price - cost_price) * stock_quantity), 0) as potential_gross_profit,
      COUNT(*) as total_items,
      COALESCE(SUM(stock_quantity), 0) as total_units
    FROM products
    WHERE status = 'active'
  `);

  const cost = stats ? stats.total_cost_value : 0;
  const retail = stats ? stats.potential_sales_value : 0;
  const profit = stats ? stats.potential_gross_profit : 0;
  const margin = retail > 0 ? Math.round(((profit / retail) * 100) * 10) / 10 : 0;

  return {
    totalCostValue: cost,
    potentialSalesValue: retail,
    potentialGrossProfit: profit,
    totalItems: stats ? stats.total_items : 0,
    totalUnits: stats ? stats.total_units : 0,
    asset_value_cost: cost,
    retail_value: retail,
    total_skus: stats ? stats.total_items : 0,
    potential_margin_pct: margin
  };
}

/**
 * Advanced product search and parametric filtering
 */
function searchProducts({ search, category, status, stockLevel, minPrice, maxPrice, limit = 200, offset = 0 }) {
  let sql = 'SELECT * FROM products WHERE 1=1';
  const params = [];

  // Status filter
  if (status && status !== 'all') {
    sql += ' AND status = ?';
    params.push(status);
  } else if (!status) {
    sql += " AND status = 'active'";
  }

  // Category filter
  if (category && category !== 'All' && category !== 'All Categories') {
    sql += ' AND category = ?';
    params.push(category);
  }

  // Text search: matches Name, SKU, Barcode, or Supplier
  if (search && search.trim()) {
    const term = `%${search.trim()}%`;
    sql += ' AND (name LIKE ? OR sku LIKE ? OR barcode LIKE ? OR supplier LIKE ?)';
    params.push(term, term, term, term);
  }

  // Stock Level filter
  if (stockLevel === 'out_of_stock') {
    sql += ' AND stock_quantity = 0';
  } else if (stockLevel === 'low_stock') {
    sql += ' AND stock_quantity > 0 AND stock_quantity <= low_stock_threshold';
  } else if (stockLevel === 'in_stock') {
    sql += ' AND stock_quantity > 0';
  }

  // Price range filters
  if (minPrice !== undefined && minPrice !== '' && !isNaN(minPrice)) {
    sql += ' AND selling_price >= ?';
    params.push(parseFloat(minPrice));
  }
  if (maxPrice !== undefined && maxPrice !== '' && !isNaN(maxPrice)) {
    sql += ' AND selling_price <= ?';
    params.push(parseFloat(maxPrice));
  }

  sql += ' ORDER BY name ASC LIMIT ? OFFSET ?';
  params.push(parseInt(limit) || 200, parseInt(offset) || 0);

  const products = query(sql, params);

  // Compute calculated dynamic status for each product
  return products.map(p => {
    let stockStatus = 'Normal';
    if (p.stock_quantity === 0) {
      stockStatus = 'Out of Stock';
    } else if (p.stock_quantity <= p.low_stock_threshold) {
      stockStatus = 'Low Stock';
    }
    return {
      ...p,
      stock_status: stockStatus,
      is_low_stock: p.stock_quantity > 0 && p.stock_quantity <= p.low_stock_threshold,
      is_out_of_stock: p.stock_quantity === 0
    };
  });
}

/**
 * Adjust stock for a single product with audit trail
 */
function adjustStock({ productId, delta, newStock, reason = 'manual_adjustment', user }) {
  const product = queryOne('SELECT * FROM products WHERE id = ?', [productId]);
  if (!product) {
    throw new Error('Product not found');
  }

  let targetStock;
  let change;

  if (newStock !== undefined) {
    targetStock = parseInt(newStock);
    change = targetStock - product.stock_quantity;
  } else if (delta !== undefined) {
    change = parseInt(delta);
    targetStock = product.stock_quantity + change;
  } else {
    throw new Error('Either delta or newStock must be provided');
  }

  if (isNaN(targetStock) || targetStock < 0) {
    throw new Error('Stock quantity cannot be less than 0');
  }

  let updatedProduct = null;
  transaction(() => {
    run('UPDATE products SET stock_quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [targetStock, productId]);
    run(
      `INSERT INTO stock_movements (product_id, previous_quantity, quantity_change, new_quantity, reason, reference_id, user_id) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [productId, product.stock_quantity, change, targetStock, reason, 'MANUAL_ADJ', user.id]
    );

    logAudit({
      userId: user.id,
      userName: user.name,
      action: 'STOCK_ADJUSTMENT',
      description: `Stock adjusted for "${product.name}" (${product.sku}): ${product.stock_quantity} → ${targetStock} (${change >= 0 ? '+' : ''}${change}). Reason: ${reason}`,
      relatedId: product.sku
    });

    updatedProduct = queryOne('SELECT * FROM products WHERE id = ?', [productId]);
  });

  return updatedProduct;
}

module.exports = {
  getValuation,
  searchProducts,
  adjustStock
};
